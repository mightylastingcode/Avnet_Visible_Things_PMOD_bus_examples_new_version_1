/*

    File:    I2C Example PMOD1 (I2C 4 pin port configuration).
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    4/5/2018

    SSP version: 1.2.0
    E2 Studio version: 5.3.1.002

    Description: Set 4 pin I2c for PMOD 1 port configuration while set pins as GPIO output pins for PMOD2 port configuration.

    <I2C Pmod 1>  Example

     PMOD 1 pins:
     1 NC
     2 NC
     3 PA02 (S7G2 Configuration for SCL, SCI7 module)
     4 PA03 (S7G2 Configuration for SDA, SCI7 module)
     5 GND
     6 VCC

     Configuration U18 port 0.7 COMM = H
     Power         U19 port 0.1 = H (Enable PMOD1 VCC)

    revision:
    v1a : PMOD1 I2C ADC  PMOD2 GPIO out
    v1b : making ads1015.c/h
    v1c : improving ads1015.c/h (file corrupted.)
    v1d : improving ads1015.c/h
    v1e : Need to do ADC start conversion every time in the while loop.  Otherwise, data does not reflect the current analog level.
 *
*/



#include "pmod_configure_thread.h"
#include "pmod_configure_thread_entry.h"   // event flag
#include <pca9535/pca9535.h>


/*-------------------------------------------------------------------------*
 * Constants:
 *-------------------------------------------------------------------------*/
// LED locations
#define LEDGRNPIN  IOPORT_PORT_11_PIN_06
#define LEDBLUPIN  IOPORT_PORT_11_PIN_07
#define LEDORGPIN  IOPORT_PORT_03_PIN_13
#define LEDREDPIN  IOPORT_PORT_03_PIN_14

#define CFG_ALL_INPUT       0b11111111
#define SET_CFG_PIN_INPUT   1
#define SET_CFG_PIN_OUTPUT  0

/*-------------------------------------------------------------------------*
 * Types:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Globals:
 *-------------------------------------------------------------------------*/
    PMOD_CONFIG_t pmodconf;  // Contain configuration for PMOD

    // each configuration registers for two io expanders (U18/U19)
    U18_PORT0_CONFIGREG_t   u18port0cfg;
    U18_PORT1_CONFIGREG_t   u18port1cfg;
    U18_PORT0_OUTREG_t      u18port0outreg;
    U18_PORT1_OUTREG_t      u18port1outreg;

    U19_PORT0_CONFIGREG_t   u19port0cfg;
    U19_PORT1_CONFIGREG_t   u19port1cfg;
    U19_PORT0_OUTREG_t      u19port0outreg;
    U19_PORT1_OUTREG_t      u19port1outreg;

    PMOD_BUS_TYPE_t         pmod_bus_type_cfg[PMOD_PORT_NUM];

/*-------------------------------------------------------------------------*
 * Prototypes:
 *-------------------------------------------------------------------------*/
    void initialzie_ioexp_registers(void);
    void setup_ioexp_registers(void);

/*---------------------------------------------------------------------------*
 * Function: pmod_configure_thread_entry
 *---------------------------------------------------------------------------*/


/* PMOD Configure Thread entry function */
void pmod_configure_thread_entry(void)
{
    g_ioport.p_api->pinWrite(LEDGRNPIN, true);
    g_ioport.p_api->pinWrite(LEDREDPIN, false);

    /////////////////////////////////////////////////
    ///  Configure the IO expander's registers
    /////////////////////////////////////////////////

    initialzie_ioexp_registers();
    setup_ioexp_registers();


    /////////////////////////////////////////////////
    ///  Transfer the U18/U19 configuration to pmodconf
    /////////////////////////////////////////////////

    pmodconf.ioexpreg.u18port0cfg   = u18port0cfg.byte;
    pmodconf.ioexpreg.u18port1cfg   = u18port1cfg.byte;
    pmodconf.ioexpreg.u18port0outreg= u18port0outreg.byte;
    pmodconf.ioexpreg.u18port1outreg= u18port1outreg.byte;

    pmodconf.ioexpreg.u19port0cfg   = u19port0cfg.byte;
    pmodconf.ioexpreg.u19port1cfg   = u19port1cfg.byte;
    pmodconf.ioexpreg.u19port0outreg= u19port0outreg.byte;
    pmodconf.ioexpreg.u19port1outreg= u19port1outreg.byte;

    //////////////////////////////////////////////////
    ///  Main Program start
    /////////////////////////////////////////////////

    g_ioport.p_api->pinWrite(LEDGRNPIN, IOPORT_LEVEL_HIGH);  // turn on green led

    setup_pmod(pmodconf);   // setup pmod1

    tx_event_flags_set(&g_config_done_flags, IOEXP_DONE_EVENT_FLAG, TX_OR);   // Configuration is done.

    while (true)
    {
        tx_thread_sleep(TX_TIMER_TICKS_PER_SECOND/100*2);
    }
}
/*
 *  Assign default value to IO Expanders' registers
 *
 *  input: None
 *  Return : None
 *
 */
void initialzie_ioexp_registers(void) {

    /////////////////////////////////////////////////
    ///  U18 Default Setup
    /////////////////////////////////////////////////

    u18port0cfg.byte     = CFG_ALL_INPUT;    // default all input.
    u18port1cfg.byte     = CFG_ALL_INPUT;    // default all input
    u18port0outreg.byte  = 0b00000000;    // default all low's
    u18port1outreg.byte  = 0b00000000;    // default all low's

    u18port0cfg.bit.pmod1_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod2_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod3_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod4_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin

    /////////////////////////////////////////////////
    ///  U19 Default Setup
    /////////////////////////////////////////////////
    ///
    u19port0cfg.byte     = CFG_ALL_INPUT;    // default all input.
    u19port1cfg.byte     = CFG_ALL_INPUT;    // default all input
    u19port0outreg.byte  = 0b00000000;    // default all low's  (all pmod power disabled)
    u19port1outreg.byte  = 0b00000000;    // default all low's

    u19port0cfg.bit.pmod1_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod2_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod3_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod4_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod5_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod6_power = SET_CFG_PIN_OUTPUT;      // set as a output pin

    u19port1cfg.bit.button1 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button2 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button3 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button4 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)

    u19port1cfg.bit.secured_element_en = SET_CFG_PIN_OUTPUT;  // set as a output pin

    u19port0outreg.bit.pmod1_power = 0;  // set power off
    u19port0outreg.bit.pmod2_power = 0;  // set power off
    u19port0outreg.bit.pmod3_power = 0;  // set power off
    u19port0outreg.bit.pmod4_power = 0;  // set power off
    u19port0outreg.bit.pmod5_power = 0;  // set power off
    u19port0outreg.bit.pmod6_power = 0;  // set power off

    u19port1outreg.bit.secured_element_en = 0;  // Secured Element disabled.
}

/*
 *  Assign user setup value to IO Expanders' registers
 *
 *  input: None
 *  Return : None
 *
 */
void setup_ioexp_registers(void) {


    /////////////////////////////////////////////////
    ///  U18 setup for PMOD1 : I2C 4PIN configuration
    //////////////////////////////////////////////////
    pmod_bus_type_cfg[PMOD1_PORT] = I2C_TYPE_4PINS_COMH;

    u18port0outreg.bit.pmod1_comms = set_pmod_com_bit(pmod_bus_type_cfg[PMOD1_PORT]);

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD1 : Power enabled
    /////////////////////////////////////////////////
    u19port0outreg.bit.pmod1_power = 1;  // pmod1 power enabled.

    /////////////////////////////////////////////////
    ///  U18 setup for PMOD2 : GPIO Type 1 12 pin configuration
    ///                        Set IO1-5 output pins (S7G2 MCU pins)
    ///                        Set IO6/7/8 output pins
    ///                        Set IO6/7/8 = 010
    ///
    /// Note IO5 (This S7G2 pin is input mode only)
    /////////////////////////////////////////////////
    pmod_bus_type_cfg[PMOD2_PORT] = GPIO_TYPE1_12PINS_COML;

    u18port0outreg.bit.pmod2_comms = set_pmod_com_bit(pmod_bus_type_cfg[PMOD2_PORT]);

    u18port0cfg.bit.pmod2_reset_io6 = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod2_io7       = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod2_io8       = SET_CFG_PIN_OUTPUT;

    u18port0outreg.bit.pmod2_reset_io6  = 0;  // make 0100 0000 initially
    u18port1outreg.bit.pmod2_io7        = 0;
    u18port1outreg.bit.pmod2_io8        = 0;

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD2 : Power enabled
    /////////////////////////////////////////////////
    u19port0outreg.bit.pmod2_power = 1;  // pmod2 power enabled.

}


/*-------------------------------------------------------------------------*
 * End of File:  pmod_configure_thread_entry.c
 *-------------------------------------------------------------------------*/
