/*

    File:  ads1015.c (Adafruit 4 channel I2C ADC Module)
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    4/6/2018

    SSP version: 1.2.0
    E2 Studio version: 5.3.1.002

    Description: Basic operations such register read and write

*/

#ifndef ADS1015_ADS1015_H_
#define ADS1015_ADS1015_H_

/*-------------------------------------------------------------------------*
 * Constants:
 *-------------------------------------------------------------------------*/

#define LED_ON 1
#define LED_OFF 0

#define ADS1015_CONVERSION_ADDR 0   // ADS1015 Data Conversion Register
#define ADS1015_CONFIGREG_ADDR  1   // ADS1015 Operational Configuration Register

/*
 *
 * Configure Register : Default = 8583h.
 *
Bit [15] OS: Operational status/single-shot conversion start
For a write status:
0 : No effect
1 : Begin a single conversion (when in power-down mode)
For a read status:
0 : Device is currently performing a conversion
1 : Device is not currently performing a conversion

 * Bits [14:12] MUX[2:0]: Input multiplexer configuration (ADS1015 only)
000 : AINP = AIN0 and AINN = AIN1 (default) 100 : AINP = AIN0 and AINN = GND
001 : AINP = AIN0 and AINN = AIN3 101 : AINP = AIN1 and AINN = GND
010 : AINP = AIN1 and AINN = AIN3 110 : AINP = AIN2 and AINN = GND
011 : AINP = AIN2 and AINN = AIN3 111 : AINP = AIN3 and AINN = GND

Bits [11:9] PGA[2:0]: Programmable gain amplifier configuration (ADS1014 and ADS1015 only)
000 : FS = ±6.144V(1) 100 : FS = ±0.512V
001 : FS = ±4.096V(1) 101 : FS = ±0.256V
010 : FS = ±2.048V (default) 110 : FS = ±0.256V
011 : FS = ±1.024V 111 : FS = ±0.256V

Bit [8] MODE: Device operating mode
0 : Continuous conversion mode
1 : Power-down single-shot mode (default)

Bits [7:5] DR[2:0]: Data rate
000 : 128SPS 100 : 1600SPS (default)
001 : 250SPS 101 : 2400SPS
010 : 490SPS 110 : 3300SPS
011 : 920SPS 111 : 3300SPS

Bit [4] COMP_MODE: Comparator mode (ADS1014 and ADS1015 only)
0 : Traditional comparator with hysteresis (default)
1 : Window comparator

Bit [3] COMP_POL: Comparator polarity (ADS1014 and ADS1015 only)
0 : Active low (default)
1 : Active high

Bit [2] COMP_LAT: Latching comparator (ADS1014 and ADS1015 only)
0 : Non-latching comparator (default)
1 : Latching comparator

Bits [1:0] COMP_QUE: Comparator queue and disable (ADS1014 and ADS1015 only)
00 : Assert after one conversion
01 : Assert after two conversions
10 : Assert after four conversions
11 : Disable comparator (default)
 *
 */

#define ADS1015_CONFIGREG_VALUE_H   0xc3   // Set the resolution = +/-4.096V, AIN0, start conversion (bit 7)
#define ADS1015_CONFIGREG_VALUE_L   0x83
#define ADS1015_CONFIGREG_VALUE     0xc383

// LED locations
#define LEDGRNPIN  IOPORT_PORT_11_PIN_06
#define LEDBLUPIN  IOPORT_PORT_11_PIN_07
#define LEDORGPIN  IOPORT_PORT_03_PIN_13
#define LEDREDPIN  IOPORT_PORT_03_PIN_14
/*-------------------------------------------------------------------------*
 * Prototypes:
 *-------------------------------------------------------------------------*/
// Subroutine Prototypes

ssp_err_t ads1015_open_driver (void);
ssp_err_t ads1015_register_write (uint8_t regaddr, uint16_t writedata);
ssp_err_t ads1015_register_read (uint8_t regaddr, uint16_t * readdata);


#endif /* ADS1015_ADS1015_H_ */

/*-------------------------------------------------------------------------*
 * End of File:  ads1015.h
 *-------------------------------------------------------------------------*/
