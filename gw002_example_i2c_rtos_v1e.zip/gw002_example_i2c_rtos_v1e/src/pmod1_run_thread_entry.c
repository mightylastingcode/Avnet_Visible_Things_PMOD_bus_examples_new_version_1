#include "pmod1_run_thread.h"
#include "pmod_configure_thread_entry.h"   // event flag
#include <pca9535/pca9535.h>
#include <ads1015/ADS1015.h>

extern PMOD_BUS_TYPE_t         pmod_bus_type_cfg[PMOD_PORT_NUM];

/* PMOD1 Run Thread entry function */
void pmod1_run_thread_entry(void)
{
    ULONG       event_flags;
    ssp_err_t   ssp_err;        // function return status

    uint16_t    deviceconfig;   // ads1016 device configuration setting (from ads1016 configuration register)
    uint16_t    devicestatus;   // ads1015 device status (from ads1016 configuration register)
    uint16_t    convdata;       // ads1015 conversion data (from ads1016 conversion data register)
    float       ain_level;      // voltage level

    tx_event_flags_get(&g_config_done_flags, IOEXP_DONE_EVENT_FLAG, TX_AND, &event_flags, TX_WAIT_FOREVER);  // Don't clear it. Leave it enabled for other threads.

    // open ads1015 driver
    ssp_err = ads1015_open_driver ();
    if (SSP_SUCCESS != ssp_err) {
        g_ioport.p_api->pinWrite(LEDREDPIN, true);  // turn on red led for error
    }

    // write configuration register and start conversion!  (Set for the continuous sampling mode)
    ssp_err = ads1015_register_write (ADS1015_CONFIGREG_ADDR,ADS1015_CONFIGREG_VALUE);
    if (SSP_SUCCESS != ssp_err) {
         g_ioport.p_api->pinWrite(LEDREDPIN, LED_ON);  // turn on red led for error
         while (1);
     }
    // read configuration register for verification
    ssp_err = ads1015_register_read (ADS1015_CONFIGREG_ADDR,&deviceconfig);
    if (SSP_SUCCESS != ssp_err) {
        g_ioport.p_api->pinWrite(LEDREDPIN, LED_ON);  // turn on red led for error
        while (1);
    } else {
        if ((ADS1015_CONFIGREG_VALUE & 0x7FFF) != deviceconfig) {  // Bit 15 OS is cleared. Don't compared that bit.
            g_ioport.p_api->pinWrite(LEDREDPIN, LED_ON);  // turn on red led for error
            while (1);
        }
    }

    while (1) {
        // read configuration register for conversion status check
        ssp_err = ads1015_register_read (ADS1015_CONFIGREG_ADDR, &devicestatus);
        if (SSP_SUCCESS != ssp_err) {
             g_ioport.p_api->pinWrite(LEDREDPIN, LED_ON);  // turn on red led for error
             while (1);
         }

        if (devicestatus & 0x8000) {    // Conversion is ready
            g_ioport.p_api->pinWrite(LEDBLUPIN, LED_ON);  // turn on blue LED
            // read the conversion data
            ssp_err = ads1015_register_read (ADS1015_CONVERSION_ADDR, &convdata);
            if (SSP_SUCCESS != ssp_err) {
                 g_ioport.p_api->pinWrite(LEDREDPIN, LED_ON);  // turn on red led for error
            } else {
                convdata = convdata >> 4;                        // shift data down by 4 bits
                ain_level = (float)( convdata * 4.096 / 2048);   // FSR = +/-4.096.  For postive voltage range, only 2048 steps.
                // write configuration register and start the conversion!  (Set for the continuous sampling mode)
                ssp_err = ads1015_register_write (ADS1015_CONFIGREG_ADDR,ADS1015_CONFIGREG_VALUE);
                if (SSP_SUCCESS != ssp_err) {
                     g_ioport.p_api->pinWrite(LEDREDPIN, LED_ON);  // turn on red led for error
                     while (1);
                 }
            }
         }
         tx_thread_sleep (10); // 100ms
    }

}
