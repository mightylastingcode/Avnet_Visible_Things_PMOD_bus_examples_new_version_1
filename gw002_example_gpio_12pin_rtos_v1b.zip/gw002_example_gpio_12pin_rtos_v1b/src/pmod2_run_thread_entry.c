#include "pmod2_run_thread.h"
#include "pmod_configure_thread_entry.h"   // event flag
#include <pca9535/pca9535.h>

extern PMOD_BUS_TYPE_t         pmod_bus_type_cfg[PMOD_PORT_NUM];


/* PMOD2 Run Thread entry function */
void pmod2_run_thread_entry(void)
{
    ULONG event_flags;

    uint8_t readdata[8];  // storing the read data

    tx_event_flags_get(&g_config_done_flags, IOEXP_DONE_EVENT_FLAG, TX_AND, &event_flags, TX_WAIT_FOREVER);  // Don't clear it. Leave it enabled for other threads.

     while (true)
     {
         for (int i=0; i<8; i++) {
             tx_mutex_get(&g_gpio_lock_mutex, TX_WAIT_FOREVER);
             read_pmode_gpio_type1_byte_port (2, readdata+i,pmod_bus_type_cfg[PMOD2_PORT]);
             tx_mutex_put(&g_gpio_lock_mutex);
             tx_thread_sleep(10);
         }
     }

}

