#include "pmod2_run_thread.h"
#include "pmod_configure_thread_entry.h"   // event flag
#include <pca9535/pca9535.h>
#include <stdio.h>  // sprintf

extern PMOD_BUS_TYPE_t         pmod_bus_type_cfg[PMOD_PORT_NUM];

char g_buffer[64];   // buffer

//#define RECEIVE_STRING_LENGTH 8
#define RECEIVE_STRING_LENGTH 1

/* PMOD2 Run Thread entry function */
void pmod2_run_thread_entry(void)
{
    ULONG event_flags;
    ssp_err_t ReturnVal;

    tx_event_flags_get(&g_config_done_flags, IOEXP_DONE_EVENT_FLAG, TX_AND, &event_flags, TX_WAIT_FOREVER);  // Don't clear it. Leave it enabled for other threads.

    // SSP_ERR_IN_USE: Maybe it is already open initially
    //ReturnVal = g_sf_comms0.p_api->open (g_sf_comms0.p_ctrl, g_sf_comms0.p_cfg);
    //if (SSP_SUCCESS != ReturnVal)
    //{
    //    g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);
    //    while(1);
    //}

    // Demonstrate the sprintf can handle floating point value.  Enable Floating support in the compiler option.
    sprintf(g_buffer, "Type %d characters, they will be echoed back.  (Board VCC = %5.2f V\r\n", RECEIVE_STRING_LENGTH, 3.30);

    ReturnVal = g_sf_comms0.p_api->write(g_sf_comms0.p_ctrl, (unsigned char *)g_buffer, strlen(g_buffer), TX_WAIT_FOREVER);
    if (SSP_SUCCESS != ReturnVal)
    {
        g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);
        while(1);
    }

     while (1)
     {
         memset(g_buffer, 0, sizeof(g_buffer));

         ReturnVal = g_sf_comms0.p_api->read(g_sf_comms0.p_ctrl, (unsigned char *)g_buffer, RECEIVE_STRING_LENGTH, TX_WAIT_FOREVER);
         if (SSP_SUCCESS != ReturnVal)
         {
             g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);
             while(1);
         }

         if (13 == g_buffer[0])
             sprintf(g_buffer + RECEIVE_STRING_LENGTH, "\r\n");  // append to the end of the location designated by g_buffer
                                                                 // + RECEIVE_STRING_LENGTH


         ReturnVal = g_sf_comms0.p_api->write(g_sf_comms0.p_ctrl, (unsigned char *)g_buffer, strlen(g_buffer), TX_WAIT_FOREVER);
         if (SSP_SUCCESS != ReturnVal)
         {
             while(1);
         }
         tx_thread_sleep (1);

     }

 }
