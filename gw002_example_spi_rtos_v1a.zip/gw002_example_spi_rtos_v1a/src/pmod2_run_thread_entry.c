#include "pmod2_run_thread.h"
#include "pmod_configure_thread_entry.h"   // event flag
#include <pca9535/pca9535.h>
#include <stdio.h>  // sprintf

extern PMOD_BUS_TYPE_t         pmod_bus_type_cfg[PMOD_PORT_NUM];

int count = 0;

/* PMOD2 Run Thread entry function */
void pmod2_run_thread_entry(void)
{
    ULONG event_flags;
    char buf[20];
    ssp_err_t err;


    tx_event_flags_get(&g_config_done_flags, IOEXP_DONE_EVENT_FLAG, TX_AND, &event_flags, TX_WAIT_FOREVER);  // Don't clear it. Leave it enabled for other threads.

    //read acceleration
    err = g_sf_spi_device0.p_api->open(g_sf_spi_device0.p_ctrl, g_sf_spi_device0.p_cfg);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);



     while (1)
     {
         // read xyz value
         buf[0] = (char)(0x80 | 0x02);
         //buf[0] = (char)(0x80 | 0x00);
         err = g_sf_spi_device0.p_api->writeRead(g_sf_spi_device0.p_ctrl, buf, &buf[7], 7, SPI_BIT_WIDTH_8_BITS, TX_WAIT_FOREVER);
         if (err)
             g_ioport.p_api->pinWrite(LEDREDPIN, true);

         //read chip id
         buf[0] = (char)(0x80 | 0x00);
         err = g_sf_spi_device0.p_api->writeRead(g_sf_spi_device0.p_ctrl, buf, &buf[7], 2, SPI_BIT_WIDTH_8_BITS, TX_WAIT_FOREVER);
         if (err)
             g_ioport.p_api->pinWrite(LEDREDPIN, true);

         //read temperature
         buf[0] = (char)(0x80 | 0x08);
         err = g_sf_spi_device0.p_api->writeRead(g_sf_spi_device0.p_ctrl, buf, &buf[7], 2, SPI_BIT_WIDTH_8_BITS, TX_WAIT_FOREVER);
         if (err)
             g_ioport.p_api->pinWrite(LEDREDPIN, true);

         tx_thread_sleep (1);
         count++;
     }

 }
