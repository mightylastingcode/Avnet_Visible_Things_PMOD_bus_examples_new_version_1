/*
 * PCA9535.c
 *
 *  Created on: Mar 28, 2018
 *      Author: mikel
 */
#include "hal_data.h"
#include "pmod_configure_thread.h"
#include <pca9535/pca9535.h>


/*

    File: pca9535.c (IO Expander device driver)
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    3/11/2018

    SSP version: 1.2.0
    E2 Studio version: 5.3.1.002

    Description: Basic operations such register read and write

    Requirement: Create SCI_I2C driver (name: g_ioexpander_pmod) with Synergy Thread Configuration.
*/

/*-------------------------------------------------------------------------*
 * Includes:
 *-------------------------------------------------------------------------*/

#include "hal_data.h"
#include <pca9535/pca9535.h>


/*-------------------------------------------------------------------------*
 * Constants:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Types:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Globals:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Prototypes:
 *-------------------------------------------------------------------------*/
// Subroutine Prototypes


/*-------------------------------------------------------------------------*
 *  Open the driver
 *
 *  input: slave device address (U18/U19)
 *  Return : ssp error status
 *-------------------------------------------------------------------------*/
ssp_err_t pca3535_open(
        uint8_t slaveaddr)   // I2C slave device address
{
    if (IOEXPANDERU18_IO_SLAVEADDRESS == slaveaddr)
        return (g_sf_i2c_io_exp_u18.p_api->open(g_sf_i2c_io_exp_u18.p_ctrl,g_sf_i2c_io_exp_u18.p_cfg));
    else if (IOEXPANDERU19_PWR_SLAVEADDRESS == slaveaddr)
        return (g_sf_i2c_io_exp_u19.p_api->open(g_sf_i2c_io_exp_u19.p_ctrl,g_sf_i2c_io_exp_u19.p_cfg));
    else
        return (!SSP_SUCCESS);
}

/*-------------------------------------------------------------------------*
 *  Write one byte to a register.
 *
 *  input: slave device address (U18/U19), register address, data to wrtie
 *  Return : ssp error status
 *-------------------------------------------------------------------------*/
ssp_err_t pca3535_register_write(
        uint8_t slaveaddr,  // I2C slave device address
        uint8_t regaddr,    // register address
        uint8_t regdata)    // write data to the register
{
    uint8_t buf[2]; // buffer to hold command, write data

    buf[0] = regaddr;
    buf[1] = regdata;

    if (IOEXPANDERU18_IO_SLAVEADDRESS == slaveaddr)
        return(g_sf_i2c_io_exp_u18.p_api->write(g_sf_i2c_io_exp_u18.p_ctrl, buf, 2, false, TX_WAIT_FOREVER));
    else if (IOEXPANDERU19_PWR_SLAVEADDRESS == slaveaddr)
        return(g_sf_i2c_io_exp_u19.p_api->write(g_sf_i2c_io_exp_u19.p_ctrl, buf, 2, false, TX_WAIT_FOREVER));
    else
        return (!SSP_SUCCESS);   //ERR_ASSERTION
}

/*-------------------------------------------------------------------------*
 *  Read the content of a register.
 *
 *  input: slave device address (U18/U19), register address, data to wrtie
 *  Return : ssp error status
 *-------------------------------------------------------------------------*/
ssp_err_t pca3535_register_read(
        uint8_t slaveaddr,  // I2C slave device address
        uint8_t regaddr,    // register address
        uint8_t *regdata)   // write data to the register
{
    uint8_t buf[2]; // buffer to hold command, write data
    ssp_err_t ssp_err;   // function return status

    // write the register address
    buf[0] = regaddr;
    if (IOEXPANDERU18_IO_SLAVEADDRESS == slaveaddr)
        ssp_err = g_sf_i2c_io_exp_u18.p_api->write(g_sf_i2c_io_exp_u18.p_ctrl, buf, 1, false, TX_WAIT_FOREVER);
    else if (IOEXPANDERU19_PWR_SLAVEADDRESS == slaveaddr)
        ssp_err = g_sf_i2c_io_exp_u19.p_api->write(g_sf_i2c_io_exp_u19.p_ctrl, buf, 1, false, TX_WAIT_FOREVER);
    else
        ssp_err = !SSP_SUCCESS;

    // read the register byte
    if (SSP_SUCCESS == ssp_err){
        if (IOEXPANDERU18_IO_SLAVEADDRESS == slaveaddr)
            ssp_err = g_sf_i2c_io_exp_u18.p_api->read(g_sf_i2c_io_exp_u18.p_ctrl, regdata, 1, false, TX_WAIT_FOREVER);
        else if (IOEXPANDERU19_PWR_SLAVEADDRESS == slaveaddr)
            ssp_err = g_sf_i2c_io_exp_u19.p_api->read(g_sf_i2c_io_exp_u19.p_ctrl, regdata, 1, false, TX_WAIT_FOREVER);
        else
            ssp_err = !SSP_SUCCESS;
    }
    return ssp_err;
}



/*-------------------------------------------------------------------------*
 *  Write 1 byte of data to a PMOD port (only for GPIO Type 1 6 or 12 pin IO
 *  configuration.)
 *
 *  input: PMOD (1-6), Port data byte to write, PMOD port Configuration
 *  Return : error flag (1 true, 0 false) *
 *-------------------------------------------------------------------------*/
bool write_pmode_gpio_type1_byte_port  (
        uint8_t pmodport,           // PMOD port address
        uint8_t writeportdata,      // Port data byte to write
        PMOD_BUS_TYPE_t pmode_type) // PMOD port Configuration
{
    bool error;         // error status (1 true, 0 false).
    uint8_t len;        // length depending on PMOD port and GPIO 6 or 12 pin configurations.
    uint8_t iopin_read_value;  // read one IO pin.

    if (pmodport == 6)
        len = 4;
    else
        if (GPIO_TYPE1_6PINS_COMH == pmode_type && 5 != pmodport)
            len = 4;
        else
            len = 8;

    for (uint8_t i=1; i<(len+1); i++) {
        error = read_write_pmod_iopin (GPIO_PIN_WRITE,pmodport, i,((writeportdata & 1<<(i-1)) ? 1 : 0), &iopin_read_value, pmode_type);
        if (error)   // error flag detected.
            break;
    }
    if (error)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    return (error);
}


/*-------------------------------------------------------------------------*
 *  Write 4 bits of data to either the upper or bottom row of a PMOD port
 *  (only for GPIO Type 1 6 or 12 pin IO configuration.)
 *
 *  input: row select, PMOD (1-6), Port data nibble to write, PMOD port Configuration
 *  Return : error flag (1 true, 0 false)
 *
 *-------------------------------------------------------------------------*/
bool write_pmode_gpio_type1_nibble_port  (
        pmod_row_select_t row_select, // Upper or Bottom row
        uint8_t pmodport,           // PMOD port address
        uint8_t writeportdata,      // Port data nibble to write
        PMOD_BUS_TYPE_t pmode_type) // PMOD port Configuration
{
    bool error;         // error status (1 true, 0 false).
    uint8_t len;        // length depending on PMOD port and GPIO 6 or 12 pin configurations.
    uint8_t iopin_read_value;  // read one IO pin.
    uint8_t firstio = 1;// first io = 1 or 5 depending on row select unless pmodport is 6

    len = 4;

    if ((pmodport == 6) || (GPIO_TYPE1_6PINS_COMH == pmode_type && 5 != pmodport)) {
        firstio = 1;  // only upper row is available for PMOD 6 or GPIO 6 pin configuration (except for PMOD 5)
    } else {
        if (BOTTOMROW == row_select) {
            firstio = 5;
            writeportdata = (uint8_t) (writeportdata << 4);
        }
    }

    for (uint8_t i=firstio; i<(len+firstio); i++) {
        error = read_write_pmod_iopin (GPIO_PIN_WRITE,pmodport, i,((writeportdata & 1<<(i-1)) ? 1 : 0), &iopin_read_value, pmode_type);
        if (error)   // error flag detected.
            break;
    }
    if (error)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    return (error);
}
/*-------------------------------------------------------------------------*
 *  Read 1 byte of data from a PMOD port (only for GPIO Type 1 6 or 12 pin IO
 *  configuration.)
 *
 *  input: PMOD (1-6), Port data byte to read, PMOD port Configuration
 *  Return : error flag (1 true, 0 false) *
 *-------------------------------------------------------------------------*/
bool read_pmode_gpio_type1_byte_port  (
        uint8_t         pmodport,       // PMOD port address
        uint8_t *       readportdata,   // Port data byte to read
        PMOD_BUS_TYPE_t pmode_type)     // PMOD port Configuration
{
    bool error;         // error status (1 true, 0 false).
    uint8_t len;        // length depending on PMOD port and GPIO 6 or 12 pin configurations.
    uint8_t iopin_read_value;  // read one IO pin.
    uint8_t readdata = 0;      // read data byte

    if (pmodport == 6)
        len = 4;
    else
        if (GPIO_TYPE1_6PINS_COMH == pmode_type && 5 != pmodport)
            len = 4;
        else
            len = 8;

    for (uint8_t i=1; i<(len+1); i++) {
        error = read_write_pmod_iopin (GPIO_PIN_READ,pmodport, i,0, &iopin_read_value, pmode_type);
        if (error)   // error flag detected.
            break;
        if (iopin_read_value)
            readdata = (uint8_t) (readdata | (1<<(i-1)));
    }
    *readportdata = readdata;
    if (error)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    return (error);
}

/*-------------------------------------------------------------------------*
 *  Read 4 bits of data from the upper or lower row of a PMOD port
 *  (only for GPIO Type 1 6 or 12 pin IO configuration.)
 *
 *  input: row select, PMOD (1-6), Port data nibble to read, PMOD port Configuration
 *  Return : error flag (1 true, 0 false) *
 *-------------------------------------------------------------------------*/
bool read_pmode_gpio_type1_nibble_port  (
        pmod_row_select_t row_select, // Upper or Bottom row
        uint8_t         pmodport,       // PMOD port address
        uint8_t *       readportdata,   // Port data byte to read
        PMOD_BUS_TYPE_t pmode_type)     // PMOD port Configuration
{
    bool error;         // error status (1 true, 0 false).
    uint8_t len;        // length depending on PMOD port and GPIO 6 or 12 pin configurations.
    uint8_t iopin_read_value;  // read one IO pin.
    uint8_t readdata = 0;      // read data byte
    uint8_t firstio = 1;// first io = 1 or 5 depending on row select unless pmodport is 6

    len = 4;

    if ((pmodport == 6) || (GPIO_TYPE1_6PINS_COMH == pmode_type && 5 != pmodport)) {
        firstio = 1;  // only upper row is available for PMOD 6 or GPIO 6 pin configuration (except for PMOD 5)
    } else {
        if (BOTTOMROW == row_select) {
            firstio = 5;
        }
    }

    for (uint8_t i=firstio; i<(len+firstio); i++) {
        error = read_write_pmod_iopin (GPIO_PIN_READ,pmodport, i,0, &iopin_read_value, pmode_type);
        if (error)   // error flag detected.
            break;
        if (iopin_read_value)
            readdata = (uint8_t) (readdata | (1<<(i-1)));
    }
    if (5 == firstio) {
        readdata = readdata >> 4;   // move the nibble down.
    }
    *readportdata = readdata;
    if (error)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    return (error);
}
/*-------------------------------------------------------------------------*
 *  Write 1 bit value to or read from PMOD (only for GPIO Type 1 IO)
 *
 *  input: read or write mode,
 *         PMOD address (1-6),
 *         io position (1-8),
 *         write bit value (0/1),
 *         read bit value variable pointer (0/1),
 *         PMOD bus configuration type
 *
 *  Return : error flag (1 true, 0 false) *
 *-------------------------------------------------------------------------*/
bool read_write_pmod_iopin (
        gpio_opmode_t   opmode,         // read or write
        uint8_t         pmodport,       // PMOD port address
        uint8_t         io_position,    // IO position (1,..,8)
        uint8_t         write_bit_val,  // write this bit value to the pin
        uint8_t *       read_bit_val,   // read the bit value from the pin. store into the location pointed by this pointer
        PMOD_BUS_TYPE_t pmode_type)     // PMOD port configuration
{
    ssp_err_t           ssp_err = SSP_SUCCESS;          // function return status.
    uint8_t             read_data;          // a byte of data to be read from one of io expander's registers.
    uint8_t             iopin_read_value;   // 1 or 0.  One bit value.
    U18_PORT0_OUTREG_t  port0outreg;        // IO6 output register for data write.
    U18_PORT1_OUTREG_t  port1outreg;        // IO7/IO8 output register for data write.
    U18_PORT0_INREG_t   port0inreg;         // IO6 input register for data read.
    U18_PORT1_INREG_t   port1inreg;         // IO7/IO8 input register for data read.
    bool                error_status = false;   // error flag
    bool                exp_io_flag = false;    // flag enabled if IO pin from
                                                // the io expander port 0/1
    ioport_port_pin_t   pin;                // MCU S7G2 GPIO pin name

    //////////////////////////////////////////
    // Synergy S7G2 IO pin
    //////////////////////////////////////////
    if (pmodport == 1)
    {
        if (GPIO_TYPE1_12PINS_COML == pmode_type) {
            switch (io_position)
            {
                case 1: pin = PMOD1_GPIO_TYPE1_12PINS_IO1; break;
                case 2: pin = PMOD1_GPIO_TYPE1_12PINS_IO2; break;
                case 3: pin = PMOD1_GPIO_TYPE1_12PINS_IO3; break;
                case 4: pin = PMOD1_GPIO_TYPE1_12PINS_IO4; break;
                case 5: pin = PMOD1_GPIO_TYPE1_12PINS_IO5; break;
                case 6:
                case 7:
                case 8: exp_io_flag = true; break;
                default: error_status = true; break;
            }
        } else if (GPIO_TYPE1_6PINS_COMH == pmode_type) {
            switch (io_position)
            {
                case 1: pin = PMOD1_GPIO_TYPE1_6PINS_IO1; break;
                case 2: pin = PMOD1_GPIO_TYPE1_6PINS_IO2; break;
                case 3: pin = PMOD1_GPIO_TYPE1_6PINS_IO3; break;
                case 4: pin = PMOD1_GPIO_TYPE1_6PINS_IO4; break;
                case 5:
                case 6:
                case 7:
                case 8:
                default: error_status = true; break;
            }
        } else {
            error_status = true;
        }
    }
    else if (pmodport == 2)
    {
        if (GPIO_TYPE1_12PINS_COML == pmode_type) {
            switch (io_position)
            {
                case 1: pin = PMOD2_GPIO_TYPE1_12PINS_IO1; break;
                case 2: pin = PMOD2_GPIO_TYPE1_12PINS_IO2; break;
                case 3: pin = PMOD2_GPIO_TYPE1_12PINS_IO3; break;
                case 4: pin = PMOD2_GPIO_TYPE1_12PINS_IO4; break;
                case 5: pin = PMOD2_GPIO_TYPE1_12PINS_IO5; break;
                case 6:
                case 7:
                case 8: exp_io_flag = true; break;
                default: error_status = true; break;
            }
        } else if (GPIO_TYPE1_6PINS_COMH == pmode_type) {
            switch (io_position)
            {
                case 1: pin = PMOD2_GPIO_TYPE1_6PINS_IO1; break;
                case 2: pin = PMOD2_GPIO_TYPE1_6PINS_IO2; break;
                case 3: pin = PMOD2_GPIO_TYPE1_6PINS_IO3; break;
                case 4: pin = PMOD2_GPIO_TYPE1_6PINS_IO4; break;
                case 5:
                case 6:
                case 7:
                case 8:
                default: error_status = true; break;
            }
        } else {
            error_status = true;
        }
    }
    else if (pmodport == 3)
    {
        if (GPIO_TYPE1_12PINS_COML == pmode_type) {
            switch (io_position)
            {
                case 1: pin = PMOD3_GPIO_TYPE1_12PINS_IO1; break;
                case 2: pin = PMOD3_GPIO_TYPE1_12PINS_IO2; break;
                case 3: pin = PMOD3_GPIO_TYPE1_12PINS_IO3; break;
                case 4: pin = PMOD3_GPIO_TYPE1_12PINS_IO4; break;
                case 5: pin = PMOD3_GPIO_TYPE1_12PINS_IO5; break;
                case 6:
                case 7:
                case 8: exp_io_flag = true; break;
                default: error_status = true; break;
            }
        } else if (GPIO_TYPE1_6PINS_COMH == pmode_type) {
            switch (io_position)
            {
                case 1: pin = PMOD3_GPIO_TYPE1_6PINS_IO1; break;
                case 2: pin = PMOD3_GPIO_TYPE1_6PINS_IO2; break;
                case 3: pin = PMOD3_GPIO_TYPE1_6PINS_IO3; break;
                case 4: pin = PMOD3_GPIO_TYPE1_6PINS_IO4; break;
                case 5:
                case 6:
                case 7:
                case 8:
                default: error_status = true; break;
            }
        } else {
            error_status = true;
        }
    }
    else if (pmodport == 4)
    {
        if (GPIO_TYPE1_12PINS_COML == pmode_type) {
            switch (io_position)
            {
                case 1: pin = PMOD4_GPIO_TYPE1_12PINS_IO1; break;
                case 2: pin = PMOD4_GPIO_TYPE1_12PINS_IO2; break;
                case 3: pin = PMOD4_GPIO_TYPE1_12PINS_IO3; break;
                case 4: pin = PMOD4_GPIO_TYPE1_12PINS_IO4; break;
                case 5: pin = PMOD4_GPIO_TYPE1_12PINS_IO5; break;
                case 6:
                case 7:
                case 8: exp_io_flag = true; break;
                default: error_status = true; break;
            }
        } else if (GPIO_TYPE1_6PINS_COMH == pmode_type) {
            switch (io_position)
            {
                case 1: pin = PMOD4_GPIO_TYPE1_6PINS_IO1; break;
                case 2: pin = PMOD4_GPIO_TYPE1_6PINS_IO2; break;
                case 3: pin = PMOD4_GPIO_TYPE1_6PINS_IO3; break;
                case 4: pin = PMOD4_GPIO_TYPE1_6PINS_IO4; break;
                case 5:
                case 6:
                case 7:
                case 8:
                default: error_status = true; break;
            }
        } else {
            error_status = true;
        }
    }
    else if (pmodport == 5)
    {
        if (GPIO_TYPE1_12PINS_COML == pmode_type || GPIO_TYPE1_6PINS_COMH == pmode_type) {
            switch (io_position)
            {
                case 1: pin = PMOD5_GPIO_TYPE1_6_12PINS_IO1; break;
                case 2: pin = PMOD5_GPIO_TYPE1_6_12PINS_IO2; break;
                case 3: pin = PMOD5_GPIO_TYPE1_6_12PINS_IO3; break;
                case 4: pin = PMOD5_GPIO_TYPE1_6_12PINS_IO4; break;
                case 5: pin = PMOD5_GPIO_TYPE1_6_12PINS_IO5; break;
                case 6: pin = PMOD5_GPIO_TYPE1_6_12PINS_IO6; break;
                case 7: pin = PMOD5_GPIO_TYPE1_6_12PINS_IO7; break;
                case 8: pin = PMOD5_GPIO_TYPE1_6_12PINS_IO8; break;
                default: error_status = true; break;
            }
        } else {
            error_status = true;
        }
    }
    else if (pmodport == 6)
    {
        if (GPIO_TYPE1_12PINS_COML == pmode_type || GPIO_TYPE1_6PINS_COMH == pmode_type) {
            switch (io_position)
            {
                case 1: pin = PMOD6_GPIO_TYPE1_6_12PINS_IO1; break;
                case 2: pin = PMOD6_GPIO_TYPE1_6_12PINS_IO2; break;
                case 3: pin = PMOD6_GPIO_TYPE1_6_12PINS_IO3; break;
                case 4: pin = PMOD6_GPIO_TYPE1_6_12PINS_IO4; break;
                default: error_status = true; break;
            }
        } else {
            error_status = true;
        }
    }
    else
    {
        error_status = true;
    }

    // Write the bit value to the output pin
    if (error_status == false && exp_io_flag == false)
    {
        if (GPIO_PIN_WRITE == opmode) {
            if (write_bit_val)
            {
                g_ioport.p_api->pinWrite(pin, IOPORT_LEVEL_HIGH);
            }
            else
            {
                g_ioport.p_api->pinWrite(pin, IOPORT_LEVEL_LOW);
            }
        } else {
            g_ioport.p_api->pinRead(pin, &iopin_read_value);
            *read_bit_val = iopin_read_value;
        }
    }

    //////////////////////////////////////////
    // IO Expanders' IO pin (U18/19)
    //////////////////////////////////////////

    if (error_status == false && exp_io_flag == true)
    {
        if (io_position == 6){
            if (GPIO_PIN_WRITE == opmode) {
                // read the port 0 input register port
                ssp_err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS, OUTPUTPORTREGP0_ADDR, &read_data);
                if (ssp_err)
                    g_ioport.p_api->pinWrite(LEDREDPIN, true);
                port0outreg.byte = read_data;
                switch (pmodport)
                {
                    case 1: port0outreg.bit.pmod1_reset_io6 = (write_bit_val ? 1 : 0);  break;
                    case 2: port0outreg.bit.pmod2_reset_io6 = (write_bit_val ? 1 : 0);  break;
                    case 3: port0outreg.bit.pmod3_reset_io6 = (write_bit_val ? 1 : 0);  break;
                    case 4: port0outreg.bit.pmod4_reset_io6 = (write_bit_val ? 1 : 0);  break;
                    default: error_status = true; break;
                }
                // write the port 0 output register port
                ssp_err = pca3535_register_write(IOEXPANDERU18_IO_SLAVEADDRESS,OUTPUTPORTREGP0_ADDR,port0outreg.byte);
                if (ssp_err)
                    g_ioport.p_api->pinWrite(LEDREDPIN, true);
            } else {  // GPIO_PIN_READ Condition
                // read the port 0 input register port
                ssp_err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS, INPUTPORTREGP0_ADDR, &read_data);
                if (ssp_err)
                    g_ioport.p_api->pinWrite(LEDREDPIN, true);
                port0inreg.byte = read_data;
                switch (pmodport)
                 {
                     case 1: iopin_read_value = port0inreg.bit.pmod1_reset_io6;  break;
                     case 2: iopin_read_value = port0inreg.bit.pmod2_reset_io6;  break;
                     case 3: iopin_read_value = port0inreg.bit.pmod3_reset_io6;  break;
                     case 4: iopin_read_value = port0inreg.bit.pmod4_reset_io6;  break;
                     default: error_status = true; break;
                 }
                *read_bit_val = iopin_read_value;
            }
        }
        else if (io_position == 7){
            if (GPIO_PIN_WRITE == opmode) {
                // read the port 0 input register port
                ssp_err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS,OUTPUTPORTREGP1_ADDR, &read_data);
                if (ssp_err)
                    g_ioport.p_api->pinWrite(LEDREDPIN, true);
                port1outreg.byte = read_data;
                switch (pmodport)
                {
                    case 1: port1outreg.bit.pmod1_io7 = (write_bit_val ? 1 : 0);  break;
                    case 2: port1outreg.bit.pmod2_io7 = (write_bit_val ? 1 : 0);  break;
                    case 3: port1outreg.bit.pmod3_io7 = (write_bit_val ? 1 : 0);  break;
                    case 4: port1outreg.bit.pmod4_io7 = (write_bit_val ? 1 : 0);  break;
                    default: error_status = true; break;
                }
                // write the port 0 output register port
                ssp_err = pca3535_register_write(IOEXPANDERU18_IO_SLAVEADDRESS,OUTPUTPORTREGP1_ADDR,port1outreg.byte);
                if (ssp_err)
                    g_ioport.p_api->pinWrite(LEDREDPIN, true);
            } else {    // GPIO_PIN_READ Condition
                // read the port 1 input register port
                ssp_err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS, INPUTPORTREGP1_ADDR, &read_data);
                if (ssp_err)
                    g_ioport.p_api->pinWrite(LEDREDPIN, true);
                port1inreg.byte = read_data;
                switch (pmodport)
                 {
                     case 1: iopin_read_value = port1inreg.bit.pmod1_io7;  break;
                     case 2: iopin_read_value = port1inreg.bit.pmod2_io7;  break;
                     case 3: iopin_read_value = port1inreg.bit.pmod3_io7;  break;
                     case 4: iopin_read_value = port1inreg.bit.pmod4_io7;  break;
                     default: error_status = true; break;
                 }
                 *read_bit_val = iopin_read_value;
            }
        }
        else if (io_position == 8){
            if (GPIO_PIN_WRITE == opmode) {
                // read the port 0 input register port
                ssp_err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS,OUTPUTPORTREGP1_ADDR, &read_data);
                if (ssp_err)
                    g_ioport.p_api->pinWrite(LEDREDPIN, true);
                port1outreg.byte = read_data;
                switch (pmodport)
                {
                    case 1: port1outreg.bit.pmod1_io8 = (write_bit_val ? 1 : 0);  break;
                    case 2: port1outreg.bit.pmod2_io8 = (write_bit_val ? 1 : 0);  break;
                    case 3: port1outreg.bit.pmod3_io8 = (write_bit_val ? 1 : 0);  break;
                    case 4: port1outreg.bit.pmod4_io8 = (write_bit_val ? 1 : 0);  break;
                    default: error_status = true; break;
                }
                // write the port 0 output register port
                ssp_err = pca3535_register_write(IOEXPANDERU18_IO_SLAVEADDRESS,OUTPUTPORTREGP1_ADDR,port1outreg.byte);
                if (ssp_err)
                    g_ioport.p_api->pinWrite(LEDREDPIN, true);
            } else {    // GPIO_PIN_READ Condition
                // read the port 1 input register port
                ssp_err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS, INPUTPORTREGP1_ADDR, &read_data);
                if (ssp_err)
                    g_ioport.p_api->pinWrite(LEDREDPIN, true);
                port1inreg.byte = read_data;
                switch (pmodport)
                 {
                     case 1: iopin_read_value = port1inreg.bit.pmod1_io8;  break;
                     case 2: iopin_read_value = port1inreg.bit.pmod2_io8;  break;
                     case 3: iopin_read_value = port1inreg.bit.pmod3_io8;  break;
                     case 4: iopin_read_value = port1inreg.bit.pmod4_io8;  break;
                     default: error_status = true; break;
                 }
                 *read_bit_val = iopin_read_value;
            }
        }
    }
    return (true == error_status || ssp_err != SSP_SUCCESS);
}

/*-------------------------------------------------------------------------*
 *  Write the configuration (port direction and value) to 8 registers (U18 port0/1 + U19 port 0/1)
 *
 *  input: 8 bytes of the user's configuration
 *  Return : None.
 *-------------------------------------------------------------------------*/

//////////////////////////////////////////////////////////////////
//
// setup pmod port I/O, Type, Power.
//
//
// input: u18port0cfg    = u18 port 0 pin direction  (PMOD RST/COM)
//        u18port1cfg    = u18 port 1 pin direction
//        u18port0outreg = u18 port 0 output register (PMOD IO7/8)
//        u18port1outreg = u18 port 1 output register
//        u19port0cfg    = u19 port 0 pin direction   (PMOD power)
//        u19port0outreg = u19 port 0 output register
//
//
// return: None
//////////////////////////////////////////////////////////////////

// IO Expander 1
// PORT 0 - 0=output, 1=input
// bit 0  PMOD4 RESET pin
// bit 1  PMOD3 RESET pin
// bit 2  PMOD2 RESET pin
// bit 3  PMOD1 RESET pin
// bit 4  PMOD4 COMMS Mode pin (Output only)
// bit 5  PMOD3 COMMS Mode pin (Output only)
// bit 6  PMOD2 COMMS Mode pin (Output only)
// bit 7  PMOD1 COMMS Mode pin (Output only)


// IO Expander 1
// PORT 1 - 0=output, 1=input
// bit 0  PMOD4 IO7 pin
// bit 1  PMOD4 IO8 pin
// bit 2  PMOD3 IO7 pin
// bit 3  PMOD3 IO8 pin
// bit 4  PMOD2 IO7 pin
// bit 5  PMOD2 IO8 pin
// bit 6  PMOD1 IO7 pin
// bit 7  PMOD1 IO8 pin

// IO Expander 2
// PORT 0 - 0=output, 1=input
// bit 0  NC (input only)
// bit 1  PMOD1 POWER pin (Output only)
// bit 2  PMOD2 POWER pin (Output only)
// bit 3  PMOD3 POWER pin (Output only)
// bit 4  PMOD4 POWER pin (Output only)
// bit 5  PMOD5 POWER pin (Output only)
// bit 6  PMOD6 POWER pin (Output only)
// bit 7  NC (input only)

// IO Expander 2
// PORT 1 - 0=output, 1=input
// bit 0  NC (input only)
// bit 1  NC (input only)
// bit 2  Button 1 pin (Input only)
// bit 3  Button 1 pin (Input only)
// bit 4  Button 1 pin (Input only)
// bit 5  Button 1 pin (Input only)
// bit 6  Secure Element Enable pin (Output only)
// bit 7  NC (input only)
//
void setup_pmod(PMOD_CONFIG_t pmodconf) {

    ssp_err_t ssp_err;          // function return status
    uint8_t register_data;  // data from register read




    uint8_t setupregaddr[REGNUM_IOEXP_SETUP/2];   // An array to store reg value to write to U18/19

    setupregaddr[0] = CONFIGREGP0_ADDR;
    setupregaddr[1] = CONFIGREGP1_ADDR;
    setupregaddr[2] = OUTPUTPORTREGP0_ADDR;
    setupregaddr[3] = OUTPUTPORTREGP1_ADDR;



    /////////////////////////////////////////////////////////////////////////////////////
    //    U18
    /////////////////////////////////////////////////////////////////////////////////////

    // open the driver
    ssp_err = pca3535_open(IOEXPANDERU18_IO_SLAVEADDRESS);
    if (ssp_err)
        g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);


    // change the slave address for U18 expander
    //ssp_err = pca3535_setslaveaddress(IOEXPANDER1_IO_SLAVEADDRESS);
    //if (ssp_err)
    //    g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);


    for (int index = 0; index < (REGNUM_IOEXP_SETUP/2); index++) {
        // write to the register
        ssp_err = pca3535_register_write(IOEXPANDERU18_IO_SLAVEADDRESS,setupregaddr[index],pmodconf.byte_array[index]);
        if (ssp_err)
            g_ioport.p_api->pinWrite(LEDREDPIN, true);

        // read and verify the register value
        ssp_err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS,setupregaddr[index], &register_data);
        if (ssp_err)
            g_ioport.p_api->pinWrite(LEDREDPIN, true);
        if (pmodconf.byte_array[index] != register_data)        // data verify
            g_ioport.p_api->pinWrite(LEDORGPIN, true);
    }

    /////////////////////////////////////////////////////////////////////////////////////
    //    U19
    /////////////////////////////////////////////////////////////////////////////////////

    // change the slave address for U19 expander
    //ssp_err = pca3535_setslaveaddress(IOEXPANDER2_PWR_SLAVEADDRESS);
    //if (ssp_err)
    //    g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);

    // open the driver
    ssp_err = pca3535_open(IOEXPANDERU19_PWR_SLAVEADDRESS);
    if (ssp_err)
        g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);


    for (int index = 0; index < (REGNUM_IOEXP_SETUP/2); index++) {
        // write to the register
        ssp_err = pca3535_register_write(IOEXPANDERU19_PWR_SLAVEADDRESS,setupregaddr[index],pmodconf.byte_array[(REGNUM_IOEXP_SETUP/2)+index]);
        if (ssp_err)
            g_ioport.p_api->pinWrite(LEDREDPIN, true);

        // read and verify the register value
        ssp_err = pca3535_register_read(IOEXPANDERU19_PWR_SLAVEADDRESS,setupregaddr[index], &register_data);
        if (ssp_err)
            g_ioport.p_api->pinWrite(LEDREDPIN, true);
        if (pmodconf.byte_array[(REGNUM_IOEXP_SETUP/2)+index] != register_data)        // data verify
            g_ioport.p_api->pinWrite(LEDORGPIN, true);
    }

}



/*-------------------------------------------------------------------------*
 *  Set the comms bit of the PMOD port according to the PMOD bus configuration
 *
 *  input: PMOD bus configuration
 *  Return : the value of the comms bit.
 *
 *  Type list (COMMS = L)
 *      GPIO_TYPE1_12PINS_COML
 *      UART_TYPE4A_12PINS_COML
 *      UART_TYPE4_6PINS_COML
 *      SPI_TYPE2A_12PINS_COML
 *      SPI_TYPE2_6PINS_COML
 *
 *  Type list (COMMS = L)
 *      GPIO_TYPE1_6PINS_COMH
 *      I2C_TYPE_4PINS_COMH
 *      UART_TYPE3_6PINS_COMH
 *
 * Type list (No COMMS requirement)
 *      HBRIDGE_TYPE5,
 *      HBRIDGE_TYPE6
 *
 *-------------------------------------------------------------------------*/
uint8_t set_pmod_com_bit (PMOD_BUS_TYPE_t pmod_type) {
    if (GPIO_TYPE1_6PINS_COMH == pmod_type || UART_TYPE3_6PINS_COMH == pmod_type || I2C_TYPE_4PINS_COMH == pmod_type)
        return 1;
    else
        return 0;
}

/*-------------------------------------------------------------------------*
 * End of File:  pca9535.c
 *-------------------------------------------------------------------------*/
