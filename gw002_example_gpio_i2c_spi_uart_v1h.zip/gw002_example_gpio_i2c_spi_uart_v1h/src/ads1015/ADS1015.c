/*

    File:  ads1015.c (Adafruit 4 channel I2C ADC Module)
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    4/6/2018

    SSP version: 1.2.0
    E2 Studio version: 5.3.1.002

    Description: Basic operations such register read and write

*/

/*-------------------------------------------------------------------------*
 * Includes:
 *-------------------------------------------------------------------------*/

#include "hal_data.h"
#include "pmod6_run_thread.h"
#include <ads1015/ads1015.h>

/*-------------------------------------------------------------------------*
 * Constants:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Types:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Globals:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Prototypes:
 *-------------------------------------------------------------------------*/
// Subroutine Prototypes

/*-------------------------------------------------------------------------*
 *  Open the driver
 *
 *  input:  None
 *  Return : ssp error status
 *-------------------------------------------------------------------------*/
ssp_err_t ads1015_open_driver (void){
    ssp_err_t ssp_err;  // error status

    ssp_err = g_ads1015.p_api->open(g_ads1015.p_ctrl, g_ads1015.p_cfg);
    if (SSP_SUCCESS != ssp_err) {
        g_ioport.p_api->pinWrite(LEDREDPIN, true);  // turn on red led for error
    }
    return ssp_err;
}

/*-------------------------------------------------------------------------*
 *  Write to an ADS1015 register
 *
 *  input:  register address, 16 bit write data
 *  Return : ssp error status
 *-------------------------------------------------------------------------*/
ssp_err_t ads1015_register_write (uint8_t regaddr, uint16_t writedata){
    ssp_err_t ssp_err;  // error status
    uint8_t wrbuf[4];   // buffer to send register address, write data

    // write configuration register and start conversion.
    wrbuf[0] = regaddr;
    wrbuf[1] = (uint8_t)((writedata >> 8) & 0x00ff);
    wrbuf[2] = (uint8_t)(writedata & 0x00ff);

    ssp_err = g_ads1015.p_api->write(g_ads1015.p_ctrl, wrbuf, 3, false, TX_WAIT_FOREVER);

    if (SSP_SUCCESS != ssp_err) {
         g_ioport.p_api->pinWrite(LEDREDPIN, LED_ON);  // turn on red led for error
    }
    return ssp_err;
}

/*-------------------------------------------------------------------------*
 *  Read an ADS1015 register
 *
 *  input:  register address
 *  Return : ssp error status, the configuration register
 *-------------------------------------------------------------------------*/
ssp_err_t ads1015_register_read (uint8_t regaddr, uint16_t * readdata){
    ssp_err_t ssp_err;  // error status
    uint8_t rdbuf[4];   // buffer to send register address, receive read data
    uint16_t tempdata;  // temporary data variable

    // read configuration register
    rdbuf[0] = regaddr;
    ssp_err = g_ads1015.p_api->write(g_ads1015.p_ctrl, rdbuf, 1, false, TX_WAIT_FOREVER);
    if (SSP_SUCCESS != ssp_err) {
         g_ioport.p_api->pinWrite(LEDREDPIN, LED_ON);  // turn on red led for error
     } else {
         ssp_err = g_ads1015.p_api->read(g_ads1015.p_ctrl, rdbuf, 2, false, TX_WAIT_FOREVER);
         if (SSP_SUCCESS != ssp_err) {
             g_ioport.p_api->pinWrite(LEDREDPIN, LED_ON);  // turn on red led for error
         } else {
             tempdata = rdbuf[0];
             tempdata = (uint16_t) (tempdata << (uint16_t) 8);
             tempdata = (uint16_t) (tempdata + (uint16_t) rdbuf[1]);
             *readdata = tempdata;
         }
     }
     return ssp_err;
}


/*-------------------------------------------------------------------------*
 * End of File:  ads1015.c
 *-------------------------------------------------------------------------*/
