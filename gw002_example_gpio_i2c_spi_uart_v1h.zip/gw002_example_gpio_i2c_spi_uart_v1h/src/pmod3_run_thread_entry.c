#include "pmod3_run_thread.h"
#include "pmod_configure_thread_entry.h"   // event flag
#include <pca9535/pca9535.h>
#include <stdio.h>  // sprintf

extern PMOD_BUS_TYPE_t         pmod_bus_type_cfg[PMOD_PORT_NUM];

uint16_t g_pmod3_xacc, g_pmod3_yacc, g_pmod3_zacc;  // X,Y,Z acceleration data
uint8_t  g_pmod3_dev_id;                            // device id
float    g_pmod3_tempc;                             // temperature in C
int count = 0;

// function prototype
uint16_t convert_acc_data(uint8_t msbyte, uint8_t lsbyte);

/* PMOD2 Run Thread entry function */
void pmod3_run_thread_entry(void)
{
    ULONG event_flags;
    char buf[20];
    ssp_err_t err;
    float tempk,tempc;



    tx_event_flags_get(&g_config_done_flags, IOEXP_DONE_EVENT_FLAG, TX_AND, &event_flags, TX_WAIT_FOREVER);  // Don't clear it. Leave it enabled for other threads.

    //read acceleration
    err = g_sf_spi_device0.p_api->open(g_sf_spi_device0.p_ctrl, g_sf_spi_device0.p_cfg);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);



     while (1)
     {
         //------------------------------------------------------------------------------------------------------------
         // g_gpio_lock_mutex is required if you configure some GPIO pins for this PMOD port
         // because u18 io expander is a shared resource among the running threads.  (See pmod1_run_thread_entry for
         // example code.

         //tx_mutex_get(&g_gpio_lock_mutex, TX_WAIT_FOREVER);
         //write_pmode_gpio_type1_byte_port or read_pmode_gpio_type1_byte_port
         //tx_mutex_put(&g_gpio_lock_mutex);
         //------------------------------------------------------------------------------------------------------------

         // read xyz value
         // xacc = buf [9][7:0] + buf [8][7:4] where buf [8][0] = new data status (1=new data, 0=old data)
         // yacc = buf[11][7:0] + buf[10][7:4] where buf[10][0] = new data status (1=new data, 0=old data)
         // zacc = buf[13][7:0] + buf[12][7:4] where buf[12][0] = new data status (1=new data, 0=old data)
         //
         //note: buf[7] = not valid data.

         buf[0] = (char)(0x80 | 0x02);
         //buf[0] = (char)(0x80 | 0x00);
         err = g_sf_spi_device0.p_api->writeRead(g_sf_spi_device0.p_ctrl, buf, &buf[7], 7, SPI_BIT_WIDTH_8_BITS, TX_WAIT_FOREVER);
         if (err)
             g_ioport.p_api->pinWrite(LEDREDPIN, true);
         g_pmod3_xacc = convert_acc_data(buf[9],buf[8]);
         g_pmod3_yacc = convert_acc_data(buf[11],buf[10]);
         g_pmod3_zacc = convert_acc_data(buf[13],buf[12]);

         //read chip id = buf[8]
         buf[0] = (char)(0x80 | 0x00);
         err = g_sf_spi_device0.p_api->writeRead(g_sf_spi_device0.p_ctrl, buf, &buf[7], 2, SPI_BIT_WIDTH_8_BITS, TX_WAIT_FOREVER);
         if (err)
             g_ioport.p_api->pinWrite(LEDREDPIN, true);
         g_pmod3_dev_id = buf[8];

         //read temperature = buf[8]
         // temp (K) = 296.15 K + 0.5 K/LSB x buf[8]
         // temp (C) = temp (K) - 273.15

         buf[0] = (char)(0x80 | 0x08);
         err = g_sf_spi_device0.p_api->writeRead(g_sf_spi_device0.p_ctrl, buf, &buf[7], 2, SPI_BIT_WIDTH_8_BITS, TX_WAIT_FOREVER);
         if (err)
             g_ioport.p_api->pinWrite(LEDREDPIN, true);
         tempk = 296.15 + 0.5 * (signed) buf[8];
         tempc = tempk - 273.15;
         g_pmod3_tempc = tempc;

         tx_thread_sleep (10);  // 10x10 ms
         count++;
     }

 }

// acc = msbyte[7:0] + lsbyte[7:4] where lsbyte[8][0] = new data status (1=new data, 0=old data)
uint16_t convert_acc_data(uint8_t msbyte, uint8_t lsbyte) {
    uint16_t tempdata;


    tempdata = msbyte;
    tempdata = (uint16_t) (tempdata << (uint16_t) 4);

    lsbyte = (lsbyte >> 4) & 0x0f;
    tempdata = (uint16_t) (tempdata + (uint16_t) lsbyte);
    return tempdata;
}
