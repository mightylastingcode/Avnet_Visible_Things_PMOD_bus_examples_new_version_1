/*

    File:    Combined GPIO/I2C/SPI/UART Example.
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    4/16/2018

    SSP version: 1.2.0
    E2 Studio version: 5.3.1.002

    Description:  Configuration

    PMOD1 : GPIO Type 1, 12 pins (Use 8 LEDs to display PMOD 2 input pattern)
    PMOD2 : GPIO type 1, 12 pins (inputs for 8 jumper wires to either VCC or GND)
    PMOD4 : UART Type 4, 6  pins (Print the PMOD2 input pattern on PC serial term)  SCI5  Asy UART mode
    PMOD6 : I2C 4 pins (read the voltage level from the potentiometer)  IIC1 framework driver
    PMOD3 : SPI Type 2 6 pins (read xyz, and device ID)  SCI1 Simple SPI mode

    revision:
    v1a :  PMOD1 GPIO type 1, 12 pins (LED lights)
    v1b/c :  PMOD2 GPIO type 1, 12 pins (input). Make sure that both pmod 1 and pmod2 thread have
           enough shared time.
    v1d : add PMOD 4 (UART).  Choosing PMOD 4 because it is easy to connect to UART module.
    v1e : clean up the code.
    v1f : add PMOD 6 (i2c ads1015)
    v1g : add PMOD 3 (spi bmc150)
    v1h : Correct the tx delay in some threads.   Increase UART speed to 115200.
          ThreadX source is included in the HAL thread configuration for TraceX analysis.

 *
 *
*/




#include "pmod_configure_thread.h"
#include "pmod_configure_thread_entry.h"   // event flag
#include <pca9535/pca9535.h>


/*-------------------------------------------------------------------------*
 * Constants:
 *-------------------------------------------------------------------------*/
// LED locations
#define LEDGRNPIN  IOPORT_PORT_11_PIN_06
#define LEDBLUPIN  IOPORT_PORT_11_PIN_07
#define LEDORGPIN  IOPORT_PORT_03_PIN_13
#define LEDREDPIN  IOPORT_PORT_03_PIN_14

#define CFG_ALL_INPUT       0b11111111
#define SET_CFG_PIN_INPUT   1
#define SET_CFG_PIN_OUTPUT  0

/*-------------------------------------------------------------------------*
 * Types:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Globals:
 *-------------------------------------------------------------------------*/
    PMOD_CONFIG_t pmodconf;  // Contain configuration for PMOD

    // each configuration registers for two io expanders (U18/U19)
    U18_PORT0_CONFIGREG_t   u18port0cfg;
    U18_PORT1_CONFIGREG_t   u18port1cfg;
    U18_PORT0_OUTREG_t      u18port0outreg;
    U18_PORT1_OUTREG_t      u18port1outreg;

    U19_PORT0_CONFIGREG_t   u19port0cfg;
    U19_PORT1_CONFIGREG_t   u19port1cfg;
    U19_PORT0_OUTREG_t      u19port0outreg;
    U19_PORT1_OUTREG_t      u19port1outreg;

    PMOD_BUS_TYPE_t         pmod_bus_type_cfg[PMOD_PORT_NUM];

/*-------------------------------------------------------------------------*
 * Prototypes:
 *-------------------------------------------------------------------------*/
    void initialzie_ioexp_registers(void);
    void setup_ioexp_registers(void);

/*---------------------------------------------------------------------------*
 * Function: pmod_configure_thread_entry
 *---------------------------------------------------------------------------*/


/* PMOD Configure Thread entry function */
void pmod_configure_thread_entry(void)
{
    /////////////////////////////////////////////////
    ///  Configure the IO expander's registers
    /////////////////////////////////////////////////

    initialzie_ioexp_registers();
    setup_ioexp_registers();


    /////////////////////////////////////////////////
    ///  Transfer the U18/U19 configuration to pmodconf
    /////////////////////////////////////////////////

    pmodconf.ioexpreg.u18port0cfg   = u18port0cfg.byte;
    pmodconf.ioexpreg.u18port1cfg   = u18port1cfg.byte;
    pmodconf.ioexpreg.u18port0outreg= u18port0outreg.byte;
    pmodconf.ioexpreg.u18port1outreg= u18port1outreg.byte;

    pmodconf.ioexpreg.u19port0cfg   = u19port0cfg.byte;
    pmodconf.ioexpreg.u19port1cfg   = u19port1cfg.byte;
    pmodconf.ioexpreg.u19port0outreg= u19port0outreg.byte;
    pmodconf.ioexpreg.u19port1outreg= u19port1outreg.byte;

    //////////////////////////////////////////////////
    ///  Main Program start
    /////////////////////////////////////////////////

    g_ioport.p_api->pinWrite(LEDGRNPIN, IOPORT_LEVEL_HIGH);  // turn on green led

    setup_pmod(pmodconf);   // setup pmod1

    tx_event_flags_set(&g_config_done_flags, IOEXP_DONE_EVENT_FLAG, TX_OR);   // Configuration is done.

    while (true)
    {
        //tx_thread_sleep(TX_TIMER_TICKS_PER_SECOND/100*2);
        tx_thread_sleep(10);  // 10 x 10ms

    }
}
/*
 *  Assign default value to IO Expanders' registers
 *
 *  input: None
 *  Return : None
 *
 */
void initialzie_ioexp_registers(void) {

    /////////////////////////////////////////////////
    ///  U18 Default Setup
    /////////////////////////////////////////////////

    u18port0cfg.byte     = CFG_ALL_INPUT;    // default all input.
    u18port1cfg.byte     = CFG_ALL_INPUT;    // default all input
    u18port0outreg.byte  = 0b00000000;    // default all low's
    u18port1outreg.byte  = 0b00000000;    // default all low's

    u18port0cfg.bit.pmod1_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod2_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod3_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod4_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin

    /////////////////////////////////////////////////
    ///  U19 Default Setup
    /////////////////////////////////////////////////
    ///
    u19port0cfg.byte     = CFG_ALL_INPUT;    // default all input.
    u19port1cfg.byte     = CFG_ALL_INPUT;    // default all input
    u19port0outreg.byte  = 0b00000000;    // default all low's  (all pmod power disabled)
    u19port1outreg.byte  = 0b00000000;    // default all low's

    u19port0cfg.bit.pmod1_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod2_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod3_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod4_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod5_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod6_power = SET_CFG_PIN_OUTPUT;      // set as a output pin

    u19port1cfg.bit.button1 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button2 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button3 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button4 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)

    u19port1cfg.bit.secured_element_en = SET_CFG_PIN_OUTPUT;  // set as a output pin

    u19port0outreg.bit.pmod1_power = 0;  // set power off
    u19port0outreg.bit.pmod2_power = 0;  // set power off
    u19port0outreg.bit.pmod3_power = 0;  // set power off
    u19port0outreg.bit.pmod4_power = 0;  // set power off
    u19port0outreg.bit.pmod5_power = 0;  // set power off
    u19port0outreg.bit.pmod6_power = 0;  // set power off

    u19port1outreg.bit.secured_element_en = 0;  // Secured Element disabled.
}

/*
 *  Assign user setup value to IO Expanders' registers
 *
 *  input: None
 *  Return : None
 *
 */
void setup_ioexp_registers(void) {


    /////////////////////////////////////////////////
    ///  U18 setup for PMOD1 : GPIO Type 1 12 pin configuration
    ///                        Set IO1-5 output pins (S7G2 MCU pins)
    ///                        Set IO6/7/8 output pins
    ///                        Set IO6/7/8 =001
    //////////////////////////////////////////////////
    pmod_bus_type_cfg[PMOD1_PORT] = GPIO_TYPE1_12PINS_COML;

    u18port0outreg.bit.pmod1_comms = set_pmod_com_bit(pmod_bus_type_cfg[PMOD1_PORT]);

    u18port0cfg.bit.pmod1_reset_io6 = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod1_io7       = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod1_io8       = SET_CFG_PIN_OUTPUT;

    u18port0outreg.bit.pmod1_reset_io6  = 1;  // make 0010 0000 initially
    u18port1outreg.bit.pmod1_io7        = 0;
    u18port1outreg.bit.pmod1_io8        = 0;

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD1 : Power enabled
    /////////////////////////////////////////////////
    u19port0outreg.bit.pmod1_power = 1;  // pmod1 power enabled.

    /////////////////////////////////////////////////
    ///  U18 setup for PMOD2 : GPIO Type 1 12 pin configuration
    ///                        Set IO1-5 input pins (S7G2 MCU pins)
    ///                        Set IO6/7/8 input pins
    //////////////////////////////////////////////////
    pmod_bus_type_cfg[PMOD2_PORT] = GPIO_TYPE1_12PINS_COML;

    u18port0cfg.bit.pmod2_reset_io6 = SET_CFG_PIN_INPUT;
    u18port1cfg.bit.pmod2_io7       = SET_CFG_PIN_INPUT;
    u18port1cfg.bit.pmod2_io8       = SET_CFG_PIN_INPUT;

    u18port0outreg.bit.pmod2_comms = set_pmod_com_bit(pmod_bus_type_cfg[PMOD2_PORT]);

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD2 : Power enabled
    /////////////////////////////////////////////////
    u19port0outreg.bit.pmod2_power = 1;  // pmod2 power enabled.

    /////////////////////////////////////////////////
    ///  U18 setup for PMOD3 : SPI Type 2 6 pin configuration
    /////////////////////////////////////////////////
    pmod_bus_type_cfg[PMOD3_PORT] = SPI_TYPE2_6PINS_COML;


    u18port0outreg.bit.pmod3_comms = set_pmod_com_bit(pmod_bus_type_cfg[PMOD3_PORT]);

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD3 : Power enabled
    /////////////////////////////////////////////////
    u19port0outreg.bit.pmod3_power = 1;  // pmod3 power enabled.


    /////////////////////////////////////////////////
    ///  U18 setup for PMOD4 : UART 4 6 pin configuration
    /////////////////////////////////////////////////
    pmod_bus_type_cfg[PMOD4_PORT] = UART_TYPE4_6PINS_COML;


    u18port0outreg.bit.pmod4_comms = set_pmod_com_bit(pmod_bus_type_cfg[PMOD4_PORT]);

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD4 : Power disabled (not needed)
    /////////////////////////////////////////////////
    u19port0outreg.bit.pmod4_power = 0;  // pmod2 power enabled.

    /////////////////////////////////////////////////
    ///  U18 setup for PMOD6 : I2C 4 pin configuration
    /////////////////////////////////////////////////
    pmod_bus_type_cfg[PMOD6_PORT] = I2C_TYPE_4PINS_COMH;

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD6 : Power enabled
    /////////////////////////////////////////////////
    u19port0outreg.bit.pmod6_power = 1;  // pmod6 power enabled.

}


/*-------------------------------------------------------------------------*
 * End of File:  pmod_configure_thread_entry.c
 *-------------------------------------------------------------------------*/
