/* generated thread source file - do not edit */
#include "pmod6_run_thread.h"

TX_THREAD pmod6_run_thread;
void pmod6_run_thread_create(void);
static void pmod6_run_thread_func(ULONG thread_input);
/** Alignment requires using pragma for IAR. GCC is done through attribute. */
#if defined(__ICCARM__)
#pragma data_alignment = BSP_STACK_ALIGNMENT
#endif
static uint8_t pmod6_run_thread_stack[1024] BSP_PLACE_IN_SECTION(".stack.pmod6_run_thread") BSP_ALIGN_VARIABLE(BSP_STACK_ALIGNMENT);
#if !defined(SSP_SUPPRESS_ISR_g_i2c2) && !defined(SSP_SUPPRESS_ISR_IIC1)
SSP_VECTOR_DEFINE_CHAN(iic_rxi_isr, IIC, RXI, 1);
#endif
#if !defined(SSP_SUPPRESS_ISR_g_i2c2) && !defined(SSP_SUPPRESS_ISR_IIC1)
SSP_VECTOR_DEFINE_CHAN(iic_txi_isr, IIC, TXI, 1);
#endif
#if !defined(SSP_SUPPRESS_ISR_g_i2c2) && !defined(SSP_SUPPRESS_ISR_IIC1)
SSP_VECTOR_DEFINE_CHAN(iic_tei_isr, IIC, TEI, 1);
#endif
#if !defined(SSP_SUPPRESS_ISR_g_i2c2) && !defined(SSP_SUPPRESS_ISR_IIC1)
SSP_VECTOR_DEFINE_CHAN(iic_eri_isr, IIC, ERI, 1);
#endif
riic_instance_ctrl_t g_i2c2_ctrl;
const i2c_cfg_t g_i2c2_cfg =
{ .channel = 1, .rate = I2C_RATE_FAST, .slave = 0x48, .addr_mode = I2C_ADDR_MODE_7BIT,
#define SYNERGY_NOT_DEFINED (1)            
#if (SYNERGY_NOT_DEFINED == SYNERGY_NOT_DEFINED)
  .p_transfer_tx = NULL,
#else
  .p_transfer_tx = &SYNERGY_NOT_DEFINED,
#endif
#if (SYNERGY_NOT_DEFINED == SYNERGY_NOT_DEFINED)
  .p_transfer_rx = NULL,
#else
  .p_transfer_rx = &SYNERGY_NOT_DEFINED,
#endif
#undef SYNERGY_NOT_DEFINED	
  .p_callback = NULL,
  .p_context = (void *) &g_i2c2, .rxi_ipl = (2), .txi_ipl = (2), .tei_ipl = (2), .eri_ipl = (2), .p_extend = NULL, };
/* Instance structure to use this module. */
const i2c_master_instance_t g_i2c2 =
{ .p_ctrl = &g_i2c2_ctrl, .p_cfg = &g_i2c2_cfg, .p_api = &g_i2c_master_on_riic };
sf_i2c_instance_ctrl_t g_ads1015_ctrl =
{ .p_lower_lvl_ctrl = &g_i2c2_ctrl, };
const sf_i2c_cfg_t g_ads1015_cfg =
{ .p_bus = (sf_i2c_bus_t *) &g_sf_i2c_bus1, .p_lower_lvl_cfg = &g_i2c2_cfg, };
/* Instance structure to use this module. */
const sf_i2c_instance_t g_ads1015 =
{ .p_ctrl = &g_ads1015_ctrl, .p_cfg = &g_ads1015_cfg, .p_api = &g_sf_i2c_on_sf_i2c };
extern bool g_ssp_common_initialized;
extern uint32_t g_ssp_common_thread_count;
extern TX_SEMAPHORE g_ssp_common_initialized_semaphore;
void g_hal_init(void);

void pmod6_run_thread_create(void)
{
    /* Increment count so we will know the number of ISDE created threads. */
    g_ssp_common_thread_count++;

    /* Initialize each kernel object. */

    tx_thread_create (&pmod6_run_thread, (CHAR *) "PMOD6 I2C ADS1015 Thread", pmod6_run_thread_func, (ULONG) NULL,
                      &pmod6_run_thread_stack, 1024, 1, 1, 1, TX_AUTO_START);
}

static void pmod6_run_thread_func(ULONG thread_input)
{
    /* Not currently using thread_input. */
    SSP_PARAMETER_NOT_USED (thread_input);

    /* First thread will take care of common initialization. */
    UINT err;
    err = tx_semaphore_get (&g_ssp_common_initialized_semaphore, TX_WAIT_FOREVER);

    while (TX_SUCCESS != err)
    {
        /* Check err, problem occurred. */
        BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
    }

    /* Only perform common initialization if this is the first thread to execute. */
    if (false == g_ssp_common_initialized)
    {
        /* Later threads will not run this code. */
        g_ssp_common_initialized = true;

        /* Perform common module initialization. */
        g_hal_init ();

        /* Now that common initialization is done, let other threads through. */
        /* First decrement by 1 since 1 thread has already come through. */
        g_ssp_common_thread_count--;
        while (g_ssp_common_thread_count > 0)
        {
            err = tx_semaphore_put (&g_ssp_common_initialized_semaphore);

            while (TX_SUCCESS != err)
            {
                /* Check err, problem occurred. */
                BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
            }

            g_ssp_common_thread_count--;
        }
    }

    /* Initialize each module instance. */

    /* Enter user code for this thread. */
    pmod6_run_thread_entry ();
}
