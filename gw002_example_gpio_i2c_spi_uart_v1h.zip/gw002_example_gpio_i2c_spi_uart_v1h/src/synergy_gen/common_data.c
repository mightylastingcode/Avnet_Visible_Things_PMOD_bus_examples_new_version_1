/* generated common source file - do not edit */
#include "common_data.h"
static TX_MUTEX sf_bus_mutex_g_sf_spi_bus0;
static TX_EVENT_FLAGS_GROUP sf_bus_eventflag_g_sf_spi_bus0;
static sf_spi_ctrl_t * p_sf_curr_ctrl_g_sf_spi_bus0;

sf_spi_bus_t g_sf_spi_bus0 =
{ .p_bus_name = (uint8_t *) "g_sf_spi_bus0", .channel = 1, .freq_hz_min = 0,
  .p_lock_mutex = &sf_bus_mutex_g_sf_spi_bus0, .p_sync_eventflag = &sf_bus_eventflag_g_sf_spi_bus0, .pp_curr_ctrl =
          (sf_spi_ctrl_t **) &p_sf_curr_ctrl_g_sf_spi_bus0,
  .p_lower_lvl_api = (spi_api_t *) &g_spi_on_sci, .device_count = 0, };
static TX_MUTEX sf_bus_mutex_g_sf_i2c_bus1;
static TX_EVENT_FLAGS_GROUP sf_bus_eventflag_g_sf_i2c_bus1;
static sf_i2c_instance_ctrl_t * sf_curr_ctrl_g_sf_i2c_bus1;
static sf_i2c_instance_ctrl_t * sf_curr_bus_ctrl_g_sf_i2c_bus1;
sf_i2c_bus_t g_sf_i2c_bus1 =
{ .p_bus_name = (uint8_t *) "g_sf_i2c_bus1", .channel = 1, .p_lock_mutex = &sf_bus_mutex_g_sf_i2c_bus1,
  .p_sync_eventflag = &sf_bus_eventflag_g_sf_i2c_bus1, .pp_curr_ctrl = (sf_i2c_ctrl_t **) &sf_curr_ctrl_g_sf_i2c_bus1,
  .p_lower_lvl_api = (i2c_api_master_t *) &g_i2c_master_on_riic, .device_count = 0, .pp_curr_bus_ctrl =
          (sf_i2c_ctrl_t **) &sf_curr_bus_ctrl_g_sf_i2c_bus1, };
static TX_MUTEX sf_bus_mutex_g_sf_i2c_bus0;
static TX_EVENT_FLAGS_GROUP sf_bus_eventflag_g_sf_i2c_bus0;
static sf_i2c_instance_ctrl_t * sf_curr_ctrl_g_sf_i2c_bus0;
static sf_i2c_instance_ctrl_t * sf_curr_bus_ctrl_g_sf_i2c_bus0;
sf_i2c_bus_t g_sf_i2c_bus0 =
{ .p_bus_name = (uint8_t *) "g_sf_i2c_bus0", .channel = 3, .p_lock_mutex = &sf_bus_mutex_g_sf_i2c_bus0,
  .p_sync_eventflag = &sf_bus_eventflag_g_sf_i2c_bus0, .pp_curr_ctrl = (sf_i2c_ctrl_t **) &sf_curr_ctrl_g_sf_i2c_bus0,
  .p_lower_lvl_api = (i2c_api_master_t *) &g_i2c_master_on_sci, .device_count = 0, .pp_curr_bus_ctrl =
          (sf_i2c_ctrl_t **) &sf_curr_bus_ctrl_g_sf_i2c_bus0, };
void g_common_init(void)
{
}
