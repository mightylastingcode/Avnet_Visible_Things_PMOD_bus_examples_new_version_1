/* generated thread header file - do not edit */
#ifndef PMOD6_RUN_THREAD_H_
#define PMOD6_RUN_THREAD_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus 
extern "C" void pmod6_run_thread_entry(void);
#else 
extern void pmod6_run_thread_entry(void);
#endif
#include "r_riic.h"
#include "r_i2c_api.h"
#include "sf_i2c.h"
#include "sf_i2c_api.h"
#ifdef __cplusplus
extern "C"
{
#endif
extern const i2c_cfg_t g_i2c2_cfg;
/** I2C on RIIC Instance. */
extern const i2c_master_instance_t g_i2c2;
#ifndef NULL
void NULL(i2c_callback_args_t * p_args);
#endif
/* SF I2C on SF I2C Instance. */
extern const sf_i2c_instance_t g_ads1015;
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* PMOD6_RUN_THREAD_H_ */
