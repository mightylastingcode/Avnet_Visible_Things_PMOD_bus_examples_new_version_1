/* generated thread header file - do not edit */
#ifndef PMOD3_RUN_THREAD_H_
#define PMOD3_RUN_THREAD_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus 
extern "C" void pmod3_run_thread_entry(void);
#else 
extern void pmod3_run_thread_entry(void);
#endif
#include "r_dtc.h"
#include "r_transfer_api.h"
#include "r_sci_spi.h"
#include "r_spi_api.h"
#include "sf_spi.h"
#include "sf_spi_api.h"
#ifdef __cplusplus
extern "C"
{
#endif
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer3;
#ifndef NULL
void NULL(transfer_callback_args_t * p_args);
#endif
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer2;
#ifndef NULL
void NULL(transfer_callback_args_t * p_args);
#endif
extern const spi_cfg_t g_spi0_cfg;
/** SPI on SCI Instance. */
extern const spi_instance_t g_spi0;
#ifndef NULL
void NULL(spi_callback_args_t * p_args);
#endif
/* SF SPI on SF SPI Instance. */
extern const sf_spi_instance_t g_sf_spi_device0;
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* PMOD3_RUN_THREAD_H_ */
