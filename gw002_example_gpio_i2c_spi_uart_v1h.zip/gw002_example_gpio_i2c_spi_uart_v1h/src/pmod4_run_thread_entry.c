#include "pmod4_run_thread.h"
#include "pmod_configure_thread_entry.h"   // event flag
#include <pca9535/pca9535.h>
#include <stdio.h>  // sprintf

#define refreshdelay  20  // 20 x10  msec delay

extern PMOD_BUS_TYPE_t         pmod_bus_type_cfg[PMOD_PORT_NUM];

extern uint8_t      g_pmod2_port_data;
extern float        g_pmod6_ads1015_ch0_level;                  // voltage level
extern uint16_t     g_pmod3_xacc, g_pmod3_yacc, g_pmod3_zacc;   // X,Y,Z acceleration data
extern uint8_t      g_pmod3_dev_id;                             // device id
extern float        g_pmod3_tempc;                              // temperature in C

char g_buffer[100];   // UART buffer

/* PMOD4 Run Thread entry function */
void pmod4_run_thread_entry(void)
{
    ULONG event_flags;
    ssp_err_t ReturnVal;

    tx_event_flags_get(&g_config_done_flags, IOEXP_DONE_EVENT_FLAG, TX_AND, &event_flags, TX_WAIT_FOREVER);  // Don't clear it. Leave it enabled for other threads.

    // SSP_ERR_IN_USE: Maybe it is already open initially
    //ReturnVal = g_sf_comms0.p_api->open (g_sf_comms0.p_ctrl, g_sf_comms0.p_cfg);
    //if (SSP_SUCCESS != ReturnVal)
    //{
    //    g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);
    //    while(1);
    //}

    // Demonstrate the sprintf can handle floating point value.  Enable Floating support in the compiler option.

    while (true) {

        //------------------------------------------------------------------------------------------------------------
        // g_gpio_lock_mutex is required if you configure some GPIO pins for this PMOD port
        // because u18 io expander is a shared resource among the running threads.  (See pmod1_run_thread_entry for
        // example code.

        //tx_mutex_get(&g_gpio_lock_mutex, TX_WAIT_FOREVER);
        //write_pmode_gpio_type1_byte_port or read_pmode_gpio_type1_byte_port
        //tx_mutex_put(&g_gpio_lock_mutex);
        //------------------------------------------------------------------------------------------------------------


        sprintf(g_buffer, "PMOD2 input: %2x PMOD6 ACH0 : %5.2f PMOD3 ID = %2x XACC = %3x YACC = %3x ZACC = %3x TempC = %5.2f\r\n",
                g_pmod2_port_data, g_pmod6_ads1015_ch0_level, g_pmod3_dev_id, g_pmod3_xacc, g_pmod3_yacc, g_pmod3_zacc, g_pmod3_tempc);

        ReturnVal = g_sf_comms0.p_api->write(g_sf_comms0.p_ctrl, (unsigned char *)g_buffer, strlen(g_buffer), TX_WAIT_FOREVER);
        if (SSP_SUCCESS != ReturnVal)
        {
            g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);
            while(1);
        }

        tx_thread_sleep (refreshdelay);
    }

}
