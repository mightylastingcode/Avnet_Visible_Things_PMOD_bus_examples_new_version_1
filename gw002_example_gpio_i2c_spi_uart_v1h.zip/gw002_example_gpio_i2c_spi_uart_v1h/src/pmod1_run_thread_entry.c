#include "pmod1_run_thread.h"
#include "pmod_configure_thread_entry.h"   // event flag
#include <pca9535/pca9535.h>

extern PMOD_BUS_TYPE_t         pmod_bus_type_cfg[PMOD_PORT_NUM];

#define refreshleddelay 10         // 10x10 msec delay time.

extern uint8_t g_pmod2_port_data;

/* PMOD1 Run Thread entry function */
void pmod1_run_thread_entry(void)
{
    ULONG event_flags;
    //uint8_t writedata[8] = {0xAA, 0x00, 0x55, 0x00, 0x55, 0x00, 0xAA, 0x00}; // write data
    uint8_t writedata[8] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80}; // write data

    tx_event_flags_get(&g_config_done_flags, IOEXP_DONE_EVENT_FLAG, TX_AND, &event_flags, TX_WAIT_FOREVER);  // Don't clear it. Leave it enabled for other threads.


     while (true)
     {
         for (int i=0; i<8; i++) {
             tx_mutex_get(&g_gpio_lock_mutex, TX_WAIT_FOREVER);
             write_pmode_gpio_type1_byte_port (1, ~g_pmod2_port_data,pmod_bus_type_cfg[PMOD1_PORT]);
             tx_mutex_put(&g_gpio_lock_mutex);
             tx_thread_sleep(refreshleddelay);

         }
     }

}


