/*

    File:    GPIO input and output example (GPIO Type 1 6 pin port configuration).
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    4/4/2018

    SSP version: 1.2.0
    E2 Studio version: 5.3.1.002

    Description: Set for 4 GPIO output for PMOD 1 port.  Set for 4 GPIO input for PMOD 2 port.  Connect both ports together.
                 Write different values to PMOD1 port for testing purpose and read the values back from PMOD2 port.


    <GPIO Type 1 PMOD1>  Example

     IO.1 PA05 (S7G2)
     IO.2 PA04 (S7G2)
     IO.3 PA03 (S7G2)
     IO.4 PA02 (S7G2)
     IO.5-8 = IO.1-4 (Both rows are connected to the same S7G2 pins.)

     Configuration U18 port 0.7 COMM = L
     Direction     U18 port0/1 Direction (all output)
     Power         U19 port 0.1 = H (Enable PMOD1 VCC)

    <GPIO Type 1 PMOD1>  Example

     IO.1 PB02 (S7G2)
     IO.2 PB04 (S7G2)
     IO.3 PB05 (S7G2)
     IO.4 PB03 (S7G2)
     IO.5-8 = IO.1-4  (Both rows are connected to the same S7G2 pins.)

     Configuration U18 port 0.6 COMM = L
     Direction     U18 port0/1 Direction (all input)
     Power         U19 port 0.2 = H (Enable PMOD2 VCC)

     Note: PMOD6 : It has only 4 IO pins.
           IO5 of PMOD[2-6] cannot be configured as output pins due to S7G2 P00x's restriction.

    revision:
    v1a : 1) Configure PMOD 2 port's pins as input pins (also GPIO type 1 6 pin configuration).  Then connect PMOD 1 and 2 together.
          But, this time we will only write 4 bit data.

 *
 *
*/




#include "pmod_configure_thread.h"
#include "pmod_configure_thread_entry.h"   // event flag
#include <pca9535/pca9535.h>


/*-------------------------------------------------------------------------*
 * Constants:
 *-------------------------------------------------------------------------*/
// LED locations
#define LEDGRNPIN  IOPORT_PORT_11_PIN_06
#define LEDBLUPIN  IOPORT_PORT_11_PIN_07
#define LEDORGPIN  IOPORT_PORT_03_PIN_13
#define LEDREDPIN  IOPORT_PORT_03_PIN_14

#define CFG_ALL_INPUT       0b11111111
#define SET_CFG_PIN_INPUT   1
#define SET_CFG_PIN_OUTPUT  0

/*-------------------------------------------------------------------------*
 * Types:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Globals:
 *-------------------------------------------------------------------------*/
    PMOD_CONFIG_t pmodconf;  // Contain configuration for PMOD

    // each configuration registers for two io expanders (U18/U19)
    U18_PORT0_CONFIGREG_t   u18port0cfg;
    U18_PORT1_CONFIGREG_t   u18port1cfg;
    U18_PORT0_OUTREG_t      u18port0outreg;
    U18_PORT1_OUTREG_t      u18port1outreg;

    U19_PORT0_CONFIGREG_t   u19port0cfg;
    U19_PORT1_CONFIGREG_t   u19port1cfg;
    U19_PORT0_OUTREG_t      u19port0outreg;
    U19_PORT1_OUTREG_t      u19port1outreg;

    PMOD_BUS_TYPE_t         pmod_bus_type_cfg[PMOD_PORT_NUM];

/*-------------------------------------------------------------------------*
 * Prototypes:
 *-------------------------------------------------------------------------*/
    void initialzie_ioexp_registers(void);
    void setup_ioexp_registers(void);

/*---------------------------------------------------------------------------*
 * Function: pmod_configure_thread_entry
 *---------------------------------------------------------------------------*/


/* PMOD Configure Thread entry function */
void pmod_configure_thread_entry(void)
{
    /////////////////////////////////////////////////
    ///  Configure the IO expander's registers
    /////////////////////////////////////////////////

    initialzie_ioexp_registers();
    setup_ioexp_registers();


    /////////////////////////////////////////////////
    ///  Transfer the U18/U19 configuration to pmodconf
    /////////////////////////////////////////////////

    pmodconf.ioexpreg.u18port0cfg   = u18port0cfg.byte;
    pmodconf.ioexpreg.u18port1cfg   = u18port1cfg.byte;
    pmodconf.ioexpreg.u18port0outreg= u18port0outreg.byte;
    pmodconf.ioexpreg.u18port1outreg= u18port1outreg.byte;

    pmodconf.ioexpreg.u19port0cfg   = u19port0cfg.byte;
    pmodconf.ioexpreg.u19port1cfg   = u19port1cfg.byte;
    pmodconf.ioexpreg.u19port0outreg= u19port0outreg.byte;
    pmodconf.ioexpreg.u19port1outreg= u19port1outreg.byte;

    //////////////////////////////////////////////////
    ///  Main Program start
    /////////////////////////////////////////////////

    g_ioport.p_api->pinWrite(LEDGRNPIN, IOPORT_LEVEL_HIGH);  // turn on green led

    setup_pmod(pmodconf);   // setup pmod1

    tx_event_flags_set(&g_config_done_flags, IOEXP_DONE_EVENT_FLAG, TX_OR);   // Configuration is done.

    while (true)
    {
        tx_thread_sleep(TX_TIMER_TICKS_PER_SECOND/100*2);
    }
}
/*
 *  Assign default value to IO Expanders' registers
 *
 *  input: None
 *  Return : None
 *
 */
void initialzie_ioexp_registers(void) {

    /////////////////////////////////////////////////
    ///  U18 Default Setup
    /////////////////////////////////////////////////

    u18port0cfg.byte     = CFG_ALL_INPUT;    // default all input.
    u18port1cfg.byte     = CFG_ALL_INPUT;    // default all input
    u18port0outreg.byte  = 0b00000000;    // default all low's
    u18port1outreg.byte  = 0b00000000;    // default all low's

    u18port0cfg.bit.pmod1_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod2_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod3_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod4_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin

    /////////////////////////////////////////////////
    ///  U19 Default Setup
    /////////////////////////////////////////////////
    ///
    u19port0cfg.byte     = CFG_ALL_INPUT;    // default all input.
    u19port1cfg.byte     = CFG_ALL_INPUT;    // default all input
    u19port0outreg.byte  = 0b00000000;    // default all low's  (all pmod power disabled)
    u19port1outreg.byte  = 0b00000000;    // default all low's

    u19port0cfg.bit.pmod1_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod2_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod3_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod4_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod5_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod6_power = SET_CFG_PIN_OUTPUT;      // set as a output pin

    u19port1cfg.bit.button1 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button2 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button3 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button4 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)

    u19port1cfg.bit.secured_element_en = SET_CFG_PIN_OUTPUT;  // set as a output pin

    u19port0outreg.bit.pmod1_power = 0;  // set power off
    u19port0outreg.bit.pmod2_power = 0;  // set power off
    u19port0outreg.bit.pmod3_power = 0;  // set power off
    u19port0outreg.bit.pmod4_power = 0;  // set power off
    u19port0outreg.bit.pmod5_power = 0;  // set power off
    u19port0outreg.bit.pmod6_power = 0;  // set power off

    u19port1outreg.bit.secured_element_en = 0;  // Secured Element disabled.
}

/*
 *  Assign user setup value to IO Expanders' registers
 *
 *  input: None
 *  Return : None
 *
 */
void setup_ioexp_registers(void) {


    /////////////////////////////////////////////////
    ///  U18 setup for PMOD1 : GPIO Type 1 6 pin configuration
    ///                        Set IO1-4 output pins (S7G2 MCU pins)
    //////////////////////////////////////////////////
    pmod_bus_type_cfg[PMOD1_PORT] = GPIO_TYPE1_6PINS_COMH;

    u18port0outreg.bit.pmod1_comms = set_pmod_com_bit(pmod_bus_type_cfg[PMOD1_PORT]);

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD1 : Power enabled
    /////////////////////////////////////////////////
    u19port0outreg.bit.pmod1_power = 1;  // pmod1 power enabled.

    /////////////////////////////////////////////////
    ///  U18 setup for PMOD2 : GPIO Type 1 6 pin configuration
    ///                        Set IO1-4 input pins (S7G2 MCU pins)
    /// Note IO5 (This S7G2 pin is input mode only)
    /////////////////////////////////////////////////
    pmod_bus_type_cfg[PMOD2_PORT] = GPIO_TYPE1_6PINS_COMH;

    u18port0outreg.bit.pmod2_comms = set_pmod_com_bit(pmod_bus_type_cfg[PMOD2_PORT]);

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD2 : Power enabled
    /////////////////////////////////////////////////
    u19port0outreg.bit.pmod2_power = 1;  // pmod2 power enabled.

}


/*-------------------------------------------------------------------------*
 * End of File:  pmod_configure_thread_entry.c
 *-------------------------------------------------------------------------*/
