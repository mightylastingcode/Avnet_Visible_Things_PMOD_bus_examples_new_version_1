/*

    File: pca9535.c (IO Expander device driver)
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    3/29/2018

    SSP version: 1.2.0
    E2 Studio version: 5.3.1.002

    Description: Basic operations such register read and write

    Requirement: Create SCI_I2C driver (name: g_ioexpander_pmod) with Synergy Thread Configuration.

*/

#ifndef PCA9535_PCA9535_H_
#define PCA9535_PCA9535_H_

/*-------------------------------------------------------------------------*
 * Constants:
 *-------------------------------------------------------------------------*/

#define PMOD_PORT_NUM         6   // 6 pmod ports

#define PMOD1_PORT            0
#define PMOD2_PORT            1
#define PMOD3_PORT            2
#define PMOD4_PORT            3
#define PMOD5_PORT            4
#define PMOD6_PORT            5

#define IOEXPANDERU18_IO_SLAVEADDRESS     0x25   // control IO<8:6> and COMMS Mode for different PMOD types. (1x6,1x12,2x4)
#define IOEXPANDERU19_PWR_SLAVEADDRESS    0x27   // control PMOD power, buttons, secure element


// PCA9535 IO Expander: Internal registers
#define INPUTPORTREGP0_ADDR     0
#define INPUTPORTREGP1_ADDR     1
#define OUTPUTPORTREGP0_ADDR    2
#define OUTPUTPORTREGP1_ADDR    3
#define POLARITYINVREGP0_ADDR   4  // not used
#define POLARITYINVREGP1_ADDR   5  // not used
#define CONFIGREGP0_ADDR        6
#define CONFIGREGP1_ADDR        7

#define REGNUM_IOEXP_SETUP      8  // for pmod setup for each io expander
                                   // U18/U19 : Configure Reg + Output Reg = 2 x (2+2) = 8


// PMOD1 GPIO Type 1 pin locations (12pins)
#define PMOD1_GPIO_TYPE1_12PINS_IO1  IOPORT_PORT_10_PIN_05
#define PMOD1_GPIO_TYPE1_12PINS_IO2  IOPORT_PORT_10_PIN_02
#define PMOD1_GPIO_TYPE1_12PINS_IO3  IOPORT_PORT_10_PIN_03
#define PMOD1_GPIO_TYPE1_12PINS_IO4  IOPORT_PORT_10_PIN_04
#define PMOD1_GPIO_TYPE1_12PINS_IO5  IOPORT_PORT_04_PIN_00

// (6 pins) : only IO[1:4] exist.
#define PMOD1_GPIO_TYPE1_6PINS_IO1  IOPORT_PORT_10_PIN_05
#define PMOD1_GPIO_TYPE1_6PINS_IO2  IOPORT_PORT_10_PIN_04
#define PMOD1_GPIO_TYPE1_6PINS_IO3  IOPORT_PORT_10_PIN_03
#define PMOD1_GPIO_TYPE1_6PINS_IO4  IOPORT_PORT_10_PIN_02

// PMOD2 GPIO Type 1 pin locations
#define PMOD2_GPIO_TYPE1_12PINS_IO1  IOPORT_PORT_11_PIN_02
#define PMOD2_GPIO_TYPE1_12PINS_IO2  IOPORT_PORT_11_PIN_04
#define PMOD2_GPIO_TYPE1_12PINS_IO3  IOPORT_PORT_11_PIN_05
#define PMOD2_GPIO_TYPE1_12PINS_IO4  IOPORT_PORT_11_PIN_03
#define PMOD2_GPIO_TYPE1_12PINS_IO5  IOPORT_PORT_00_PIN_01   // only input mode allowed.

// (6 pins) : only IO[1:4] exist.
#define PMOD2_GPIO_TYPE1_6PINS_IO1  IOPORT_PORT_11_PIN_02
#define PMOD2_GPIO_TYPE1_6PINS_IO2  IOPORT_PORT_11_PIN_03
#define PMOD2_GPIO_TYPE1_6PINS_IO3  IOPORT_PORT_11_PIN_05
#define PMOD2_GPIO_TYPE1_6PINS_IO4  IOPORT_PORT_11_PIN_04

// PMOD3 GPIO Type 1 pin locations
#define PMOD3_GPIO_TYPE1_12PINS_IO1  IOPORT_PORT_07_PIN_11
#define PMOD3_GPIO_TYPE1_12PINS_IO2  IOPORT_PORT_07_PIN_09
#define PMOD3_GPIO_TYPE1_12PINS_IO3  IOPORT_PORT_07_PIN_08
#define PMOD3_GPIO_TYPE1_12PINS_IO4  IOPORT_PORT_07_PIN_10
#define PMOD3_GPIO_TYPE1_12PINS_IO5  IOPORT_PORT_00_PIN_02   // only input mode allowed

// (6 pins) : only IO[1:4] exist.
#define PMOD3_GPIO_TYPE1_6PINS_IO1  IOPORT_PORT_07_PIN_11
#define PMOD3_GPIO_TYPE1_6PINS_IO2  IOPORT_PORT_07_PIN_10
#define PMOD3_GPIO_TYPE1_6PINS_IO3  IOPORT_PORT_07_PIN_08
#define PMOD3_GPIO_TYPE1_6PINS_IO4  IOPORT_PORT_07_PIN_09

// PMOD4 GPIO Type 1 pin locations
#define PMOD4_GPIO_TYPE1_12PINS_IO1  IOPORT_PORT_05_PIN_14
#define PMOD4_GPIO_TYPE1_12PINS_IO2  IOPORT_PORT_05_PIN_09
#define PMOD4_GPIO_TYPE1_12PINS_IO3  IOPORT_PORT_05_PIN_10
#define PMOD4_GPIO_TYPE1_12PINS_IO4  IOPORT_PORT_05_PIN_08
#define PMOD4_GPIO_TYPE1_12PINS_IO5  IOPORT_PORT_00_PIN_04   // only input mode allowed.

// (6 pins) : only IO[1:4] exist.
#define PMOD4_GPIO_TYPE1_6PINS_IO1  IOPORT_PORT_05_PIN_14
#define PMOD4_GPIO_TYPE1_6PINS_IO2  IOPORT_PORT_05_PIN_08
#define PMOD4_GPIO_TYPE1_6PINS_IO3  IOPORT_PORT_05_PIN_10
#define PMOD4_GPIO_TYPE1_6PINS_IO4  IOPORT_PORT_05_PIN_09

// PMOD5 GPIO Type 1 pin locations
#define PMOD5_GPIO_TYPE1_6_12PINS_IO1  IOPORT_PORT_05_PIN_15
#define PMOD5_GPIO_TYPE1_6_12PINS_IO2  IOPORT_PORT_02_PIN_03
#define PMOD5_GPIO_TYPE1_6_12PINS_IO3  IOPORT_PORT_02_PIN_02
#define PMOD5_GPIO_TYPE1_6_12PINS_IO4  IOPORT_PORT_02_PIN_04

#define PMOD5_GPIO_TYPE1_6_12PINS_IO5  IOPORT_PORT_00_PIN_06   // only input mode allowed.
#define PMOD5_GPIO_TYPE1_6_12PINS_IO6  IOPORT_PORT_08_PIN_05
#define PMOD5_GPIO_TYPE1_6_12PINS_IO7  IOPORT_PORT_09_PIN_09
#define PMOD5_GPIO_TYPE1_6_12PINS_IO8  IOPORT_PORT_05_PIN_13

// PMOD6 GPIO Type 1 pin locations for both 6 or 12 pin setting.
#define PMOD6_GPIO_TYPE1_6_12PINS_IO1  IOPORT_PORT_08_PIN_09
#define PMOD6_GPIO_TYPE1_6_12PINS_IO2  IOPORT_PORT_08_PIN_10
#define PMOD6_GPIO_TYPE1_6_12PINS_IO3  IOPORT_PORT_02_PIN_05
#define PMOD6_GPIO_TYPE1_6_12PINS_IO4  IOPORT_PORT_02_PIN_06


// LED locations
#define LEDGRNPIN  IOPORT_PORT_11_PIN_06
#define LEDBLUPIN  IOPORT_PORT_11_PIN_07
#define LEDORGPIN  IOPORT_PORT_03_PIN_13
#define LEDREDPIN  IOPORT_PORT_03_PIN_14

/*-------------------------------------------------------------------------*
 * Types:
 *-------------------------------------------------------------------------*/
// IO Expander 1 (U18)
// PORT 0 - 0=output, 1=input (u18 port 0 configure register )
// bit 0  PMOD4 RESET pin
// bit 1  PMOD3 RESET pin
// bit 2  PMOD2 RESET pin
// bit 3  PMOD1 RESET pin
// bit 4  PMOD4 COMMS Mode pin (Output only)
// bit 5  PMOD3 COMMS Mode pin (Output only)
// bit 6  PMOD2 COMMS Mode pin (Output only)
// bit 7  PMOD1 COMMS Mode pin (Output only)

// IO Expander 1 (U18)
// PORT 1 - 0=output, 1=input (u18 port 1 configure register)
// bit 0  PMOD4 IO7 pin
// bit 1  PMOD4 IO8 pin
// bit 2  PMOD3 IO7 pin
// bit 3  PMOD3 IO8 pin
// bit 4  PMOD2 IO7 pin
// bit 5  PMOD2 IO8 pin
// bit 6  PMOD1 IO7 pin
// bit 7  PMOD1 IO8 pin

// IO Expander 2 (U19)
// PORT 0 - 0=output, 1=input (u19 port 0 configure register )
// bit 0  NC (input only)
// bit 1  PMOD1 POWER pin (Output only)
// bit 2  PMOD2 POWER pin (Output only)
// bit 3  PMOD3 POWER pin (Output only)
// bit 4  PMOD4 POWER pin (Output only)
// bit 5  PMOD5 POWER pin (Output only)
// bit 6  PMOD6 POWER pin (Output only)
// bit 7  NC (input only)

// IO Expander 2 (U19)
// PORT 1 - 0=output, 1=input  (u19 port 1 configure register)
// bit 0  NC (input only)
// bit 1  NC (input only)
// bit 2  Button 1 pin (Input only)
// bit 3  Button 1 pin (Input only)
// bit 4  Button 1 pin (Input only)
// bit 5  Button 1 pin (Input only)
// bit 6  Secure Element Enable pin (Output only)
// bit 7  NC (input only)


typedef union PMOD_CONFIG
{
    uint8_t byte_array [REGNUM_IOEXP_SETUP];  // for making writing / reading easy with loop.
    struct {
        uint8_t u18port0cfg;   // u18 port 0 configure register for input or output mode
        uint8_t u18port1cfg;   // u18 port 1 configure register for input or output mode
        uint8_t u18port0outreg;   // u18 port 0 output register
        uint8_t u18port1outreg;   // u18 port 1 output register

        uint8_t u19port0cfg;   // u19 port 0 configure register for input or output mode
        uint8_t u19port1cfg;   // u19 port 1 configure register for input or output mode
        uint8_t u19port0outreg;   // u19 port 0 output register
        uint8_t u19port1outreg;   // u19 port 1 output register
    } ioexpreg;

} PMOD_CONFIG_t;

typedef union U18_PORT0_CONFIGREG   // 1=output 0=input
{
    uint8_t byte;
    struct {
        uint8_t pmod4_reset_io6:1;  // bit 0
        uint8_t pmod3_reset_io6:1;
        uint8_t pmod2_reset_io6:1;
        uint8_t pmod1_reset_io6:1;
        uint8_t pmod4_comms:1;
        uint8_t pmod3_comms:1;
        uint8_t pmod2_comms:1;
        uint8_t pmod1_comms:1;
    } bit;
} U18_PORT0_CONFIGREG_t;

typedef union U18_PORT0_OUTREG   // output pin value
{
    uint8_t byte;
    struct {
        uint8_t pmod4_reset_io6:1;  // bit 0
        uint8_t pmod3_reset_io6:1;
        uint8_t pmod2_reset_io6:1;
        uint8_t pmod1_reset_io6:1;
        uint8_t pmod4_comms:1;
        uint8_t pmod3_comms:1;
        uint8_t pmod2_comms:1;
        uint8_t pmod1_comms:1;
    } bit;
} U18_PORT0_OUTREG_t;

typedef union U18_PORT0_INREG   // input pin value
{
    uint8_t byte;
    struct {
        uint8_t pmod4_reset_io6:1;  // bit 0
        uint8_t pmod3_reset_io6:1;
        uint8_t pmod2_reset_io6:1;
        uint8_t pmod1_reset_io6:1;
        uint8_t pmod4_comms:1;
        uint8_t pmod3_comms:1;
        uint8_t pmod2_comms:1;
        uint8_t pmod1_comms:1;
    } bit;
} U18_PORT0_INREG_t;


typedef union U18_PORT1_CONFIGREG   // 1=output 0=input
{
    uint8_t byte;
    struct {
        uint8_t pmod4_io7:1;  // bit 0
        uint8_t pmod4_io8:1;
        uint8_t pmod3_io7:1;
        uint8_t pmod3_io8:1;
        uint8_t pmod2_io7:1;
        uint8_t pmod2_io8:1;
        uint8_t pmod1_io7:1;
        uint8_t pmod1_io8:1;
    } bit;
} U18_PORT1_CONFIGREG_t;

typedef union U18_PORT1_OUTREG   // output pin value
{
    uint8_t byte;
    struct {
        uint8_t pmod4_io7:1;  // bit 0
        uint8_t pmod4_io8:1;
        uint8_t pmod3_io7:1;
        uint8_t pmod3_io8:1;
        uint8_t pmod2_io7:1;
        uint8_t pmod2_io8:1;
        uint8_t pmod1_io7:1;
        uint8_t pmod1_io8:1;
    } bit;
} U18_PORT1_OUTREG_t;

typedef union U18_PORT1_INREG   // input pin value
{
    uint8_t byte;
    struct {
        uint8_t pmod4_io7:1;  // bit 0
        uint8_t pmod4_io8:1;
        uint8_t pmod3_io7:1;
        uint8_t pmod3_io8:1;
        uint8_t pmod2_io7:1;
        uint8_t pmod2_io8:1;
        uint8_t pmod1_io7:1;
        uint8_t pmod1_io8:1;
    } bit;
} U18_PORT1_INREG_t;


typedef union U19_PORT0_CONFIGREG   // 1=output 0=input
{
    uint8_t byte;
    struct {
        uint8_t not_used_bit0:1;  // bit 0
        uint8_t pmod1_power:1;
        uint8_t pmod2_power:1;
        uint8_t pmod3_power:1;
        uint8_t pmod4_power:1;
        uint8_t pmod5_power:1;
        uint8_t pmod6_power:1;
        uint8_t not_used_bit7:1;
    } bit;
} U19_PORT0_CONFIGREG_t;

typedef union U19_PORT0_OUTREG   // output pin value
{
    uint8_t byte;
    struct {
        uint8_t not_used_bit0:1;  // bit 0
        uint8_t pmod1_power:1;
        uint8_t pmod2_power:1;
        uint8_t pmod3_power:1;
        uint8_t pmod4_power:1;
        uint8_t pmod5_power:1;
        uint8_t pmod6_power:1;
        uint8_t not_used_bit7:1;
    } bit;
} U19_PORT0_OUTREG_t;

typedef union U19_PORT1_CONFIGREG   // 1=output 0=input
{
    uint8_t byte;
    struct {
        uint8_t not_used_bit0:1;  // bit 0
        uint8_t not_used_bit1:1;  // bit 1
        uint8_t button1:1;
        uint8_t button2:1;
        uint8_t button3:1;
        uint8_t button4:1;
        uint8_t secured_element_en:1;
        uint8_t not_used_bit7:1;
    } bit;
} U19_PORT1_CONFIGREG_t;

typedef union U19_PORT1_OUTREG   // output pin value
{
    uint8_t byte;
    struct {
        uint8_t not_used_bit0:1;  // bit 0
        uint8_t not_used_bit1:1;  // bit 1
        uint8_t button1:1;
        uint8_t button2:1;
        uint8_t button3:1;
        uint8_t button4:1;
        uint8_t secured_element_en:1;
        uint8_t not_used_bit7:1;
    } bit;
} U19_PORT1_OUTREG_t;


typedef enum
   {
        GPIO_TYPE1_12PINS_COML=1,
        GPIO_TYPE1_6PINS_COMH     // applies to PMOD 1-4 (Not 5 or 6)
                                  // PMOD 5 is always a 12 pin port.
                                  // PMOD 6 is always a 6 pin port.
                                  // PMOD 5 and 6 has no comms bit.
   } PMOD_BUS_TYPE_t;

typedef enum
{
    BOTTOMROW = 1,
    UPPERROW
}   pmod_row_select_t;


typedef enum
      {
          GPIO_PIN_READ = 1,
          GPIO_PIN_WRITE
      }   gpio_opmode_t;



/*-------------------------------------------------------------------------*
 * Prototypes:
 *-------------------------------------------------------------------------*/
// Subroutine Prototypes

ssp_err_t pca3535_open(uint8_t slaveaddr);
ssp_err_t pca3535_register_write(uint8_t slaveaddr, uint8_t regaddr, uint8_t regdata);
ssp_err_t pca3535_register_read(uint8_t slaveaddr, uint8_t regaddr, uint8_t *regdata);


bool write_pmode_gpio_type1_byte_port  (
        uint8_t pmodport,           // PMOD port address
        uint8_t writeportdata,           // Port data byte to write
        PMOD_BUS_TYPE_t pmode_type); // PMOD port Configuration

bool write_pmode_gpio_type1_nibble_port  (
        pmod_row_select_t row_select, // Upper or Bottom row
        uint8_t pmodport,             // PMOD port address
        uint8_t writeportdata,       // Port data byte to write
        PMOD_BUS_TYPE_t pmode_type); // PMOD port Configuration

bool read_pmode_gpio_type1_byte_port  (
        uint8_t         pmodport,   // PMOD port address
        uint8_t *       readportdata,   // Port data byte to read
        PMOD_BUS_TYPE_t pmode_type);// PMOD port Configuration

bool read_pmode_gpio_type1_nibble_port  (
        pmod_row_select_t row_select, // Upper or Bottom row
        uint8_t         pmodport,       // PMOD port address
        uint8_t *       readportdata,   // Port data byte to read
        PMOD_BUS_TYPE_t pmode_type);     // PMOD port Configuration

bool read_write_pmod_iopin (
        gpio_opmode_t   opmode,         // read or write
        uint8_t         pmodport,       // PMOD port address
        uint8_t         io_position,    // IO position (1,..,8)
        uint8_t         write_bit_val,  // write this bit value to the pin
        uint8_t *       read_bit_val,   // read the bit value from the pin. store into the location pointed by this pointer
        PMOD_BUS_TYPE_t pmode_type);     // PMOD port configuration

uint8_t set_pmod_com_bit (PMOD_BUS_TYPE_t pmod_type);
void setup_pmod( PMOD_CONFIG_t pmodconf);


#endif /* PCA9535_PCA9535_H_ */

/*-------------------------------------------------------------------------*
 * End of File:  pca9535.h
 *-------------------------------------------------------------------------*/

